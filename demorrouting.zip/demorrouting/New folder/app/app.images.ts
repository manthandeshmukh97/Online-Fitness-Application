export class Images{
    image:string;
}