﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { AddProduct} from './app.addproduct';
import { ShowProduct} from './app.showproduct';
import { SearchProduct} from './app.searchproduct';
import { UpdateProduct} from './app.updateproduct';
import { Routes,RouterModule } from '@angular/router';

 
const route:Routes=[
{path:"",redirectTo:"show",pathMatch:'full'},
{path:"add",component:AddProduct},
{path:"show",component:ShowProduct},
{path:"search/:id",component:SearchProduct},
{path:"search",component:SearchProduct},

{path:"update",component:UpdateProduct}



];

@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(route)
        
    ],
    declarations: [
        AppComponent,AddProduct,ShowProduct,SearchProduct,UpdateProduct
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }

