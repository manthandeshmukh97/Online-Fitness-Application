import {Component} from '@angular/core';


@Component({
selector:'add-prod',
templateUrl:'app.addproduct.html'



})




export class AddProduct{
    
}