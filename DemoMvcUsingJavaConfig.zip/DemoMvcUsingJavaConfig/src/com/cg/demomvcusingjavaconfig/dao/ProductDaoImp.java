package com.cg.demomvcusingjavaconfig.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demomvcusingjavaconfig.dto.Product;
@Repository
public class ProductDaoImp implements ProductDao {

	List<Product> myList = new ArrayList<>();
	
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
		myList.add(pro);
		return pro;
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return myList;
	}

}
