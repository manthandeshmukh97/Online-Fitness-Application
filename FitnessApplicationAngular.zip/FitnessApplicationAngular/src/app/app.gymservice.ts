import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';
import {AddGym} from './app.addgym';

@Injectable({

providedIn: 'root'

})



export class GymService{

constructor(private http:HttpClient){}

    getAllGym(){

       return this.http.get("http://localhost:9096/gym/show");
    }



addAllGym(gymTwo:any){
console.log(gymTwo);
let input = new FormData();
input.append("id", gymTwo.id);
input.append("name", gymTwo.name);
input.append("address", gymTwo.address);
input.append("mobile", gymTwo.mobile);

input.append("gym.id", gymTwo.gymid);
input.append("gym.address", gymTwo.gymaddress);
input.append("gym.exercises", gymTwo.gymexercises);

input.append("gym.equipments[0].id", gymTwo.gymequipmentsid);
input.append("gym.equipments[0].name",gymTwo.gymequipmentsname);
input.append("gym.equipments[0].description",gymTwo.gymequipmentsdescription);

// input.append("gym.equipments[1].id", gymTwo.gymequipmentsid);
// input.append("gym.equipments[1].name",gymTwo.gymequipmentsname);
// input.append("gym.equipments[1].description",gymTwo.gymequipmentsdescription);

// input.append("gym.equipments[2].id", gymTwo.gymequipmentsid);
// input.append("gym.equipments[2].name",gymTwo.gymequipmentsname);
// input.append("gym.equipments[2].description",gymTwo.gymequipmentsdescription);

// input.append("gym.equipments[3].id", gymTwo.gymequipmentsid);
// input.append("gym.equipments[3].name",gymTwo.gymequipmentsname);
// input.append("gym.equipments[3].description",gymTwo.gymequipmentsdescription);

return this.http.post("http://localhost:9096/gym/add",input);
    }

    searchAllMembers(members:any)
    {
        let mid=new FormData();
        mid.append("mid",members.id);
        return this.http.post("http://localhost:9096/gym/search",mid);
 
    }

    searchAllEquipment(equipments:any)
    {
        console.log("inside service searchAllEquipment"+equipments);
       let params = new HttpParams().set("ename",equipments);
        return this.http.get("http://localhost:9096/gym/searchname",{params:params});
    }
}


