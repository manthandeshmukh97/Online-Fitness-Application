import {Component} from '@angular/core';
import { AddGym } from "./app.addgym";
import { Equipment } from "./app.equipment";


export class Member{

    id:number;
    name:string;
    address:string;
    mobile:number;
    gym:AddGym;
}