﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { AddGym} from './app.addgym';
import { Member} from './app.member';
import { ShowProduct} from './app.showproduct';
import { SearchMember} from './app.searchmember';
import { SearchEquipment} from './app.searchequipment';
import { Routes,RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { GymComponent } from './app.gymcomponent';

 
const route:Routes=[
{path:"add",component:GymComponent},
{path:"show",component:ShowProduct},
{path:"search",component:SearchMember},
{path:"searchequipment",component:SearchEquipment}



];

@NgModule({
    imports: [
        BrowserModule,RouterModule.forRoot(route),HttpClientModule,FormsModule
        
    ],
    declarations: [
        AppComponent,GymComponent,ShowProduct,SearchMember,SearchEquipment
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }

