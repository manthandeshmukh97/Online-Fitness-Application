import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Params} from '@angular/router';
import { Member} from './app.member';
import { GymService} from './app.gymservice';
import { Equipment } from './app.equipment';
import { AddGym } from './app.addgym';

@Component({
selector:'search-equipment',
templateUrl:'app.searchequipment.html'
})




export class SearchEquipment{
    equipments:Equipment[];
    model:string;
    constructor(private gymservice:GymService){}
    ngOnInit(){}

    searchEquipment()
    {
        console.log("inside serch equip..."+this.model);
       this.gymservice.searchAllEquipment(this.model).subscribe((data:any)=>this.equipments=data);
     
    }

}
    
