import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import { Member} from './app.member';
import {GymService} from './app.gymservice';
@Component({
selector:'search-member',
templateUrl:'app.searchmember.html'



})




export class SearchMember implements OnInit{
    members:Member[];
    model:any={};
    constructor(private gymservice:GymService){}
    ngOnInit(){}
    
    searchMember()
    {
       this.gymservice. searchAllMembers(this.model).subscribe((data:Member[])=>this.members=data);
     
    }

}
    
