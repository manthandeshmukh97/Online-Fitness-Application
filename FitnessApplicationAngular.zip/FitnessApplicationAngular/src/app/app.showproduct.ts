import {Component} from '@angular/core';
import { GymService } from './app.gymservice';
import { AddGym } from './app.addgym';

@Component({
selector:'show-prod',
templateUrl:'app.showproduct.html'



})




export class ShowProduct{

    gymOne:AddGym[];
    model:any={};
    constructor(private proservice:GymService){}
    
    ngOnInit(){
    
        this.proservice.getAllGym().subscribe((data:AddGym[]) => this.gymOne=data);
    }
    
}