package com.cg.demomvcusingjavaconfig.service;

import java.util.List;

import com.cg.demomvcusingjavaconfig.dto.Product;


public interface ProductService {
	
	public Product addProduct(Product pro);
	public List<Product> showProduct();

}
