package com.cg.productspringboot.service;

import java.util.List;

import com.cg.productspringboot.dto.Product;

public interface ProductService {

	
	public Product addProduct(Product pro);
	public List<Product> showAll();
	public Product getProduct(int id);

}
