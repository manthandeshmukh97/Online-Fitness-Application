package com.cg.productspringboot.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cg.productspringboot.dto.Product;

public interface ProductService {

	
	public Product addProduct(Product pro);
	public List<Product> showAll();
	public List<Product> search(String name);
	public List<Product> showByPriceBetween(double min, double max);
//	public Product getProduct(int id);
//	public Product deleteById(Product product);

}
