package com.cg.productspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productspringboot.dao.ProductDao;
import com.cg.productspringboot.dto.Product;

@Service
public class ProductServiceImp implements ProductService {
@Autowired
	ProductDao productdao;
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productdao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productdao.showAll();
	}
	


	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return productdao.findOne(id);
	}

}
