package com.cg.productspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.cg.productspringboot.dao.ProductDao;
import com.cg.productspringboot.dto.Product;

@Service
public class ProductServiceImp implements ProductService {
	@Autowired
	ProductDao productdao;
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productdao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productdao.findAll();
	}

	@Override
	public List<Product> search(String name) {
		// TODO Auto-generated method stub
		return productdao.findByName(name);
	}
	
	public List<Product> showByPriceBetween(double min, double max){
		
		return productdao.findByPriceBetween(min, max);

	}

	

	/*@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return productdao.findOne(id);
	}

	public Product deleteById(Product product) {
		// TODO Auto-generated method stub
		return	productdao.deleteId(product);
	}*/
	
}

