package com.cg.productspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productspringboot.dto.Inventory;
import com.cg.productspringboot.dto.Product;
import com.cg.productspringboot.service.ProductService;

import ch.qos.logback.core.rolling.helper.IntegerTokenConverter;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productservice;


	/*@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
	//@GetMapping("checkname")
	public String getName(@PathVariable("uname") String mname, @RequestParam("prodid") String id)
	{
		System.out.println("hiiiii");
		return "Capgemini" +mname;
	}

	@RequestMapping(method=RequestMethod.POST, value="/checkname")
	public String getData(@RequestParam("prodId") int pid, @RequestParam("prodName") String pname, 
			@RequestParam("prodPrice") String pprice) {

		System.out.println(pid+" "+pname+" "+pprice);

		return "Welcome";		
	}*/


	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Product pro) {

		Product prod = productservice.addProduct(pro);		
		if(prod==null) {
			return new ResponseEntity("Product Not Added ", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(prod, HttpStatus.OK);

	}

	@RequestMapping(value="/show",method=RequestMethod.GET)

	public ResponseEntity<List<Product>> showAllProduct(){
		List<Product> myList = productservice.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("No Product To Show ", HttpStatus.NOT_FOUND);

		}

return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);

	}

	
	@RequestMapping(value="/search",method=RequestMethod.GET)

	public ResponseEntity<List<Product>> searchProduct(@RequestParam("pname") String name){
		List<Product> myList = productservice.search(name);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Name Found ", HttpStatus.NOT_FOUND);

		}

return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);

	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public ResponseEntity<List<Product>> searchProductPrice(@RequestParam("min") double min,
			@RequestParam("max") double max){

		List<Product> myList = productservice.showByPriceBetween(min, max);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Name Found ", HttpStatus.NOT_FOUND);

		}

return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);

	}
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Product> addAll(@ModelAttribute("product") Product prod){
	/*public ResponseEntity<Product> addAll(
			@RequestParam("id") int pid, 
			@RequestParam("name") String pname,
			@RequestParam("price") double pprice, 
			@RequestParam("desc") String desc,
			@RequestParam("inid") int inid,
			@RequestParam("inname") String inname){

		Inventory inventory = new Inventory();
		inventory.setId(inid);
		inventory.setName(inname);
		
		Product prod = new Product();
		prod.setId(pid);
		prod.setName(pname);
		prod.setPrice(pprice);
		prod.setDescription(desc);
		prod.setInventory(inventory);*/
		
		Product pro = productservice.addProduct(prod);
		
		if(pro==null) {
			return new ResponseEntity("No Name Found ", HttpStatus.NOT_FOUND);	
		}
		
		
			

		

return new ResponseEntity<Product>(pro,HttpStatus.OK);

	}
	
	
	/*@RequestMapping(value="/search",method=RequestMethod.GET)
	public Product getProduct2(@RequestParam("id") int id){
		return productservice.getProduct(id);
	}


	@RequestMapping(value="/delete",method=RequestMethod.DELETE)
	public Product getDeleteProduct(@RequestParam("id") String id){
		int pid= Integer.parseInt(id);
		Product product = productservice.getProduct(pid);
		return productservice.deleteById(product);
	}*/


}
