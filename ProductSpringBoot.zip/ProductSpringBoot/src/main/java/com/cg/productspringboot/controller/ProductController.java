package com.cg.productspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productspringboot.dto.Product;
import com.cg.productspringboot.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productservice;


	/*@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
	//@GetMapping("checkname")
	public String getName(@PathVariable("uname") String mname, @RequestParam("prodid") String id)
	{
		System.out.println("hiiiii");
		return "Capgemini" +mname;
	}

	@RequestMapping(method=RequestMethod.POST, value="/checkname")
	public String getData(@RequestParam("prodId") int pid, @RequestParam("prodName") String pname, 
			@RequestParam("prodPrice") String pprice) {

		System.out.println(pid+" "+pname+" "+pprice);

		return "Welcome";		
	}*/


	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Product addProduct(@RequestBody Product pro) {

		productservice.addProduct(pro);		
		System.out.println(pro);

		return pro;

	}

	@RequestMapping(value="/show",method=RequestMethod.GET)

	public List<Product> showAllProduct(){

		return productservice.showAll();
	}
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public Product getProduct2(@RequestParam("id") int id){
		return productservice.getProduct(id);
	}
}
