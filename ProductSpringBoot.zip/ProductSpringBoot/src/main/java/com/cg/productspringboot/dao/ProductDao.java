package com.cg.productspringboot.dao;

import java.util.List;

import com.cg.productspringboot.dto.Product;

public interface ProductDao {

	public Product save(Product pro);
	public List<Product> showAll();
	public Product findOne(int id);
}
