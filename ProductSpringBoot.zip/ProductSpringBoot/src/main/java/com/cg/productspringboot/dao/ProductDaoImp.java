package com.cg.productspringboot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.productspringboot.dto.Product;

@Repository
public class ProductDaoImp implements ProductDao{

	List<Product> myList = new ArrayList<>();
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
	myList.add(pro);
	return  pro;
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return myList;
	}

	public Product findOne(int id) {
		// TODO Auto-generated method stub
		for(Product pro: myList)
			
			if(pro.getId()==id)
		
				return pro;
		return null;
	}

}
