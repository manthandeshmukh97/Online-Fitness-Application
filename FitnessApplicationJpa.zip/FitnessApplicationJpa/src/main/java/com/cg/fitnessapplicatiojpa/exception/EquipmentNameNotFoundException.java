package com.cg.fitnessapplicatiojpa.exception;

public class EquipmentNameNotFoundException extends Exception {
	
	public EquipmentNameNotFoundException() {
		
		
	}
    
public EquipmentNameNotFoundException(String msg) {
		super(msg);
		
	}
}