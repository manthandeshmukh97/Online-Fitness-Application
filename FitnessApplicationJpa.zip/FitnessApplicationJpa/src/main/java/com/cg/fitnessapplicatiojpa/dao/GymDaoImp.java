package com.cg.fitnessapplicatiojpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.fitnessapplicatiojpa.dbutil.DBUtil;
import com.cg.fitnessapplicatiojpa.dto.Equipment;
import com.cg.fitnessapplicatiojpa.dto.Gym;
import com.cg.fitnessapplicatiojpa.dto.Member;
import com.cg.fitnessapplicatiojpa.exception.DataNotSaveException;
import com.cg.fitnessapplicatiojpa.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicatiojpa.exception.MemberNotFoundException;
import com.mysql.fabric.xmlrpc.base.Array;




public class GymDaoImp implements GymDao {

	private static List<Member> members;
	private static List<Equipment> equips;
	private static List<Gym> gyms;
	EntityManager em;

	public GymDaoImp()
	{
		em=DBUtil.em;
	}

	//funtion for adding all the data to perform the operations.
	public Member save(Member member) throws DataNotSaveException  {



		//try {
		/*member.setId(member.getId());
		member.setName(member.getName());
		member.setAddress(member.getAddress());
		member.setMobile(member.getMobile());*/

		/*Gym gym = new Gym();
		List<Equipment> equip = new ArrayList<Equipment>();

		gym.setId(member.getGym().getId());
		gym.setAddress(member.getGym().getAddress());
		gym.setExercises(member.getGym().getExercises());

		System.out.println(member.getGym().getEquipmentName());
		for(Equipment equipOne:member.getGym().getEquipmentName())
		{
			equipOne.setName(equipOne.getName());
			equipOne.setDescription(equipOne.getDescription());
			equip.add(equipOne);
			//em.persist(equipOne);

		}


	 gym.setEquipmentName(equip);
	 member.setGym(gym);
		 */
		//em.persist(member.getGym());
		int gym_id = member.getGym().getId();
		Query queryOne  = em.createQuery("Select a From Gym a where gym_id= :gym_id"); 
		List<Gym> gym = queryOne.setParameter("gym_id", gym_id).getResultList(); 

		if(!(gym.isEmpty())) { 
			em.getTransaction().begin(); 
			em.persist(member); 
			//em.merge(vehicle); 
			em.getTransaction().commit(); 
		} 
		//em.persist(vehicle.getOwner()); 




		// em.persist(member.getGym().getEquipmentName());

		//members.add(member);

		return member;
	}


	public Equipment save(Equipment equipment) {
		
		em.getTransaction().begin();
		em.persist(equipment);
		em.getTransaction().commit();
		// em.persist(member.getGym().getEquipmentName());

		return equipment;
	}




	public Gym save(Gym gym) {
		System.out.println(gym);
		em.getTransaction().begin();
		em.persist(gym);
		em.getTransaction().commit();
		// em.persist(member.getGym().getEquipmentName());

		return gym;






	}

	//funtion for searching member id in the gym.
	public Member findById(int id) throws MemberNotFoundException
	{ 	

		try {
			Member member = new Member();
			TypedQuery<Member> query = em.createQuery("select m from Member m where m.id=?", Member.class);
			query.setParameter(1, id);
			member = query.getSingleResult();
			return member;
		}
		catch(Exception e)
		{
			throw new MemberNotFoundException("Member Not Found");
		}finally {
			//em.close();
		}
	}



	//Function for searching equipment name.
	public List<Gym> findByName(String equipName) throws EquipmentNameNotFoundException{

		//List<Equipment> equipmentList = new ArrayList<Equipment>();
		List<Gym> gymList = new ArrayList<Gym>();
		//List<Gym> gymListOne = new ArrayList<Gym>();
		try {
			TypedQuery<Gym> query = em.createQuery("select g from Gym g, in(g.equipmentName)e where e.name=?",Gym.class);
			query.setParameter(1,equipName);
			gymList = query.getResultList();
			return gymList;

		}
		catch(Exception e) {
			throw new EquipmentNameNotFoundException("Equipment Name Not Found");	
		}







	}

}

