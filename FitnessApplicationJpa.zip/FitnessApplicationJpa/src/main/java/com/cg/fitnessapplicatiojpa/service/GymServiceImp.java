package com.cg.fitnessapplicatiojpa.service;

import java.util.List;

import com.cg.fitnessapplicatiojpa.dao.GymDao;
import com.cg.fitnessapplicatiojpa.dao.GymDaoImp;
import com.cg.fitnessapplicatiojpa.dto.Equipment;
import com.cg.fitnessapplicatiojpa.dto.Gym;
import com.cg.fitnessapplicatiojpa.dto.Member;
import com.cg.fitnessapplicatiojpa.exception.DataNotSaveException;
import com.cg.fitnessapplicatiojpa.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicatiojpa.exception.MemberNotFoundException;




public class GymServiceImp implements GymService {

	GymDao gymDao = new GymDaoImp();
	
	public Member addMember(Member member) throws DataNotSaveException {
		// TODO Auto-generated method stub
		return gymDao.save(member);
	}

	
	public Member searchById(int id) throws MemberNotFoundException{
		// TODO Auto-generated method stub
		return gymDao.findById(id);
	}

	
	


	public Gym addGym(Gym gym) {
		// TODO Auto-generated method stub
		return gymDao.save(gym);
	}


	public Equipment addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		 return gymDao.save(equipment);
	}
	
	public List<Gym> searchByName(String equipName) throws EquipmentNameNotFoundException  {
		// TODO Auto-generated method stub
		return gymDao.findByName(equipName);
	}

}	
