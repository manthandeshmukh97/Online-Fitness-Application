package com.cg.fitnessapplicatiojpa.dto;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "member")

public class Member {

	@Id
	@Column(name = "member_id")
	private int id;
	@Column(name = "member_name")
	private String name;
	@Column(name = "member_address")
	private String address;
	@Column(name = "member_mobile")
	private BigDecimal mobile;

	@ManyToOne
	@JoinColumn(name="gym_id")
	private Gym gym;

	public Member() {

	}


	public Member(int id, String name, String address, BigDecimal mobile, Gym gym) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.mobile = mobile;
		this.gym=gym;
	}


	public Gym getGym() {
		return gym;
	}


	public void setGym(Gym gym) {
		this.gym = gym;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public BigDecimal getMobile() {
		return mobile;
	}


	public void setMobile(BigDecimal mobile) {
		this.mobile = mobile;
	}


	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", address=" + address + ", mobile=" + mobile + "]";
	}



}
