package com.cg.fitnessapplicatiojpa.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "gym")

public class Gym {
	
    @Id
    @Column(name = "gym_id")
	private int id;
    @Column(name = "gym_address")
    private String address;
    @Column(name = "gym_exercises")
    private String exercises;
    @Column(name = "equipment_name")

    
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="gym_id")
	private List<Equipment> equipmentName;

//    @OneToMany(cascade = CascadeType.ALL)
//	private List<Member> members;

	
    public Gym()
	{
	
	}

	public Gym(int id, String address, String exercises, List<Equipment> equipmentName) {
		super();
		this.id = id;
		this.address = address;
		this.exercises = exercises;
		this.equipmentName = equipmentName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getExercises() {
		return exercises;
	}

	public void setExercises(String exercises) {
		this.exercises = exercises;
	}

	public List<Equipment> getEquipmentName() {
		return equipmentName;
	}

	public void setEquipmentName(List<Equipment> equipmentName) {
		this.equipmentName = equipmentName;
	}

	@Override
	public String toString() {
		return "Gym [id=" + id + ", address=" + address + ", exercises=" + exercises + ", equipmentName="
				+ equipmentName + "]";
	}
    
    

   
	
}


	






