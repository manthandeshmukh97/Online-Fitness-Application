 package com.cg.fitnessapplicatiojpa.ui;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.fitnessapplicatiojpa.dto.Equipment;
import com.cg.fitnessapplicatiojpa.dto.Gym;
import com.cg.fitnessapplicatiojpa.dto.Member;
import com.cg.fitnessapplicatiojpa.exception.DataNotSaveException;
import com.cg.fitnessapplicatiojpa.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicatiojpa.exception.MemberNotFoundException;
import com.cg.fitnessapplicatiojpa.service.GymService;
import com.cg.fitnessapplicatiojpa.service.GymServiceImp;


public class FitnessApplication {


		public static List<Member> members;
		public static List<Equipment> equips;
		public static List<Gym> gyms;         

		public static void main(String[] args) {

			GymService gymservice = new GymServiceImp();
            Scanner scan = new Scanner(System.in);
            char ch,ch1 = 0;
			int choice = 0;
			String str="yes";

			do {
				printMenu();
				System.out.println("Enter Choice:-");
				choice = scan.nextInt();

				switch(choice) {
				

				case 1:
					
					List<Equipment> equ = new ArrayList<Equipment>();
                    List<Member> members=new ArrayList<Member>();
					
					Gym gym1=new Gym();
					
					
					System.out.println("Enter Gym Id:-");
					int gymId = scan.nextInt();
					System.out.println("Enter Gym Address:-");
					String gymAddress = scan.next();
					System.out.println("Enter Gym Exercises:-");
					String exercise = scan.next();
					
					gym1.setId(gymId);
					gym1.setAddress(gymAddress);
					gym1.setExercises(exercise);
					

					
					do {
					
						Equipment equip = new Equipment();	
						
					System.out.println("Enter Equipment Id:-");
                    int eid = scan.nextInt();
					System.out.println("Enter Equipment Name:-");
					String ename = scan.next();
					System.out.println("Enter Equipment Description:-");
					String edesc = scan.next();
					
					
					equip.setId(eid);
					equip.setName(ename);
					equip.setDescription(edesc);
					equ.add(equip);
					
				
					
					
					System.out.println("want to add another equipment");
					System.out.println("Do you want to assign another equipment??  Y/N");
					ch=scan.next().charAt(0);
					System.out.println();
					}while(ch=='Y'||ch=='y');
					gym1.setEquipmentName(equ);
					gymservice.addGym(gym1);

					break;
					
					
				case 2:
					System.out.println("Enter Gym Id:-");
					int gymid = scan.nextInt();
					do {
						
						
					
						
						
						System.out.println("Enter Member Id:-");
					int id = scan.nextInt();
					System.out.println("Enter Member Name:-");
					String name = scan.next();
					System.out.println("Enter Member Address:-");
					String address = scan.next();
					System.out.println("Enter Member Mobile No:-");
					BigDecimal mobile = scan.nextBigDecimal();
					
					Gym gym2=new Gym(gymid,null,null,null);
					
					
					
					Member member1=new Member(id,name,address,mobile,gym2);
					
					
					try {
						gymservice.addMember(member1);
						 System.out.println("Member Added...Your Id Is:-"+member1.getId());

						
					} catch (DataNotSaveException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());

					}
					
					
					System.out.println("Do you want to assign another member??  Y/N");
					ch=scan.next().charAt(0);
					System.out.println();
					}while(ch1=='Y'||ch1=='y');
					break;
				
					
					
					
					
					
					
				case 3:

					System.out.println("Enter Member Id:-");
					int memberId = scan.nextInt();
					Member member;
					try {
						member = gymservice.searchById(memberId);
						System.out.println("Please find details of member id "+memberId+
								"\nName : "+member.getName()+
								"\nAddress : "+member.getAddress()+
								"\nMobile Number : "+member.getMobile()+
								(null==member.getGym()?"\n\nGym Details are not available.":"\nGym Details\nGym Id : "+member.getGym().getId()+
								"\nGym Address : "+member.getGym().getAddress()+"\nExercises in the Gym : "+member.getGym().getExercises()));
				 
					}catch(MemberNotFoundException e) {
						System.out.println(e.getMessage());
					}
					
					
					break;
					
					//case statement for searching equipment name in the gym


				case 4:

					System.out.println("Please enter equipment name to be search:-");
					String equipName = scan.next();
					List<Gym> gymList;
					
					try {
						gymList = gymservice.searchByName(equipName);
						for(Gym gym:gymList)
						{
							System.out.println("\nGym Id : "+gym.getId()+"\nGym Address : "+gym.getAddress());
						}
						
						}
						catch (EquipmentNameNotFoundException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());

						}

					
					break;
					
					default:
						System.out.println("Wrong choice");
						break;
				}
			}
		while(choice != 3);
			//scan.close();
		}

		private static void printMenu() {
			// TODO Auto-generated method stub
			System.out.println("*******************");
			System.out.println("Fitness Application");
			System.out.println("*******************\n");

			System.out.println("1. Add Gym and Equipment");
			System.out.println("2. Add Member");
            System.out.println("3. Search Member By Id");
			System.out.println("4. Search Equipment By Name");




		}
	}

