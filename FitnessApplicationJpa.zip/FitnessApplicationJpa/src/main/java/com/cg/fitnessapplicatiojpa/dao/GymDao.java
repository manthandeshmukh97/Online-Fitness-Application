package com.cg.fitnessapplicatiojpa.dao;

import java.util.List;

import com.cg.fitnessapplicatiojpa.dto.Equipment;
import com.cg.fitnessapplicatiojpa.dto.Gym;
import com.cg.fitnessapplicatiojpa.dto.Member;
import com.cg.fitnessapplicatiojpa.exception.DataNotSaveException;
import com.cg.fitnessapplicatiojpa.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicatiojpa.exception.MemberNotFoundException;


public interface GymDao {
	
	
	public Member save(Member member) throws DataNotSaveException;
	public Gym save(Gym gym);
	public Equipment save(Equipment equipment);
	public Member findById(int id) throws MemberNotFoundException;
	public List<Gym> findByName(String equipName) throws EquipmentNameNotFoundException;
	
	
	
	

	
	

}