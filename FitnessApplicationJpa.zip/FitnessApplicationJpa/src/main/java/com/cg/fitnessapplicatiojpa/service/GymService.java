package com.cg.fitnessapplicatiojpa.service;

import java.util.List;

import com.cg.fitnessapplicatiojpa.dto.Equipment;
import com.cg.fitnessapplicatiojpa.dto.Gym;
import com.cg.fitnessapplicatiojpa.dto.Member;
import com.cg.fitnessapplicatiojpa.exception.DataNotSaveException;
import com.cg.fitnessapplicatiojpa.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicatiojpa.exception.MemberNotFoundException;



public interface GymService {
	public Member addMember(Member member) throws DataNotSaveException;
	public Gym addGym(Gym gym);
	public Equipment addEquipment(Equipment equipment);
	public Member searchById(int id) throws MemberNotFoundException;
	public List<Gym> searchByName(String equipName) throws EquipmentNameNotFoundException;
}
