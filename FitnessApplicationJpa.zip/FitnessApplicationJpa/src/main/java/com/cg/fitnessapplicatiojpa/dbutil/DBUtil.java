package com.cg.fitnessapplicatiojpa.dbutil;




import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DBUtil {

//static EntityManager em = null;

	public static EntityManager em = Persistence.createEntityManagerFactory("fitnessapplicationdemo").createEntityManager();


}