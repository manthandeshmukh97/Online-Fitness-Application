package com.cg.fitnessapplication.dao;

import java.util.List;


import com.cg.fitnessapplication.dto.Gym;
import com.cg.fitnessapplication.dto.Member;


public interface GymDao {
	
	
	public Member save(Member member);
	public Member findById(int id);
	public List<Gym> findByName(String equipName);
	
	
	
	

	
	

}
