package com.cg.fitnessapplication.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.fitnessapplication.dto.Equipment;
import com.cg.fitnessapplication.dto.Gym;
import com.cg.fitnessapplication.dto.Member;
import com.cg.fitnessapplication.ui.FitnessApplication;

public class GymDaoImp implements GymDao {
	
	private static List<Member> members;
	private static List<Equipment> equips;
	private static List<Gym> gyms;
	

	
	
	public Member save(Member member) {
		boolean memberFound=false;
		
		for(Member mem:members)
		{
			if(mem.getId()==member.getId())
			{
				memberFound=true;
				break;
			}
		}
		
		boolean gymFound=false;
		
		if(!memberFound)
		{
			for(Gym gym:gyms)
			{
				if(member.getGym().getGymId()==gym.getGymId())
				{
					member.setGym(gym);
					gymFound=true;
				}
			}
			
			if(!gymFound)
				member.setGym(null);
			
			members.add(member);
			return member;
		}
		else
			return null;
	}


	public Member findById(int id) {
		
		for(Member mem: FitnessApplication.members)
		
			if(mem.getId()==id)
		
				return mem;
		
		
		return null;
	}

	
	public List<Gym> findByName(String equipName) {
		List<Gym> gymWithEquip=new ArrayList<>();
		
		for(Gym gym: FitnessApplication.gyms)
		{
			for(Equipment equip : gym.getEquipName())
			{
				if(equip.getEquipName().equals(equipName))
				{
					gymWithEquip.add(gym);
				}
			}
		}
		
		return gymWithEquip;
	}

}
