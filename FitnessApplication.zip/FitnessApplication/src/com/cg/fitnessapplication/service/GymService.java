package com.cg.fitnessapplication.service;

import java.util.List;

import com.cg.fitnessapplication.dto.Gym;
import com.cg.fitnessapplication.dto.Member;

public interface GymService {
	public Member addMember(Member member);
	public Member searchById(int id);
	public List<Gym> searchByName(String equipName);
}
