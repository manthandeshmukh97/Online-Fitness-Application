package com.cg.fitnessapplication.service;

import java.util.List;

import com.cg.fitnessapplication.dao.GymDao;
import com.cg.fitnessapplication.dao.GymDaoImp;
import com.cg.fitnessapplication.dto.Gym;
import com.cg.fitnessapplication.dto.Member;

public class GymServiceImp implements GymService {

	GymDao gymDao = new GymDaoImp();
	
	public Member addMember(Member member) {
		// TODO Auto-generated method stub
		return gymDao.save(member);
	}

	
	public Member searchById(int id) {
		// TODO Auto-generated method stub
		return gymDao.findById(id);
	}

	
	public List<Gym> searchByName(String equipName) {
		// TODO Auto-generated method stub
		return gymDao.findByName(equipName);
	}

}
