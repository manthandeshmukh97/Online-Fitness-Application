package com.cg.fitnessapplication.dto;

import java.math.BigInteger;

public class Member {
	
	private int id;
	private String name;
	private String address;
	private BigInteger mobile;
	private Gym gym;
	
	public Member() {
		
	}
	
	
	public Member(int id, String name, String address, BigInteger mobile, Gym gym) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.mobile = mobile;
		this.gym=gym;
	}


	public Gym getGym() {
		return gym;
	}


	public void setGym(Gym gym) {
		this.gym = gym;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public BigInteger getMobile() {
		return mobile;
	}


	public void setMobile(BigInteger mobile) {
		this.mobile = mobile;
	}


	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", address=" + address + ", mobile=" + mobile + "]";
	}
	
	
	
	

}
