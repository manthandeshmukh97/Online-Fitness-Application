package com.cg.fitnessapplication.dto;

import java.util.ArrayList;
import java.util.List;

public class Gym {

	private String exercises;
	private String gymAddress;
	private List<Equipment> equipName;
	private List<Member> name;
	private int gymId;
	

	public Gym()
	{
		/*this.equipName=new ArrayList<>();
		equipName.add(new Equipment("Equip 1","Dumbell"));
		equipName.add(new Equipment("Equip 2","Barbell"));*/
	}


	public Gym(String exercises, String gymAddress, List<Equipment> equipName, List<Member> name, int gymId) {
		super();
		this.exercises = exercises;
		this.gymAddress = gymAddress;
		this.equipName = equipName;
		this.name = name;
		this.gymId = gymId;
	}


	public String getExercises() {
		return exercises;
	}


	public void setExercises(String exercises) {
		this.exercises = exercises;
	}


	public String getGymAddress() {
		return gymAddress;
	}


	public void setGymAddress(String gymAddress) {
		this.gymAddress = gymAddress;
	}


	public List<Equipment> getEquipName() {
		return equipName;
	}


	public void setEquipName(List<Equipment> equipName) {
		this.equipName = equipName;
	}


	public List<Member> getName() {
		return name;
	}


	public void setName(List<Member> name) {
		this.name = name;
	}


	public int getGymId() {
		return gymId;
	}


	public void setGymId(int gymId) {
		this.gymId = gymId;
	}


	@Override
	public String toString() {
		return "Gym [exercises=" + exercises + ", gymAddress=" + gymAddress + ", equipName=" + equipName + ", name="
				+ name + ", gymId=" + gymId + "]";
	}

	

	




}
