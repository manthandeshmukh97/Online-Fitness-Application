package com.cg.fitnessapplication.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.fitnessapplication.dto.Equipment;
import com.cg.fitnessapplication.dto.Gym;
import com.cg.fitnessapplication.dto.Member;
import com.cg.fitnessapplication.service.GymService;
import com.cg.fitnessapplication.service.GymServiceImp;

public class FitnessApplication {


	public static List<Member> members;
	public static List<Equipment> equips;
	public static List<Gym> gyms;         
	static
	{

		equips=new ArrayList<>();
		members=new ArrayList<>();
		gyms=new ArrayList<>();

//		equips.add(new Equipment("Equip 1","Dumbell"));
//		equips.add(new Equipment("Equip 2","Barbell"));

		Gym gym1=new Gym("Bench Press, Squat, Biceps Curl", "Sai Gym, Amravati", equips, null, 1);

		equips=new ArrayList<>();
		
		equips.add(new Equipment("Dumbell","Dumbell.........."));
		equips.add(new Equipment("Barbell","Barbell.........."));
		
		Gym gym2=new Gym("Bench Press, Squat, Biceps Curl", "Gold Gym, Pune", equips, null, 2);

		Member mem1=new Member(101, "Mahesh", "Wakad", new BigInteger("123456789"), gym1);
		Member mem2=new Member(102, "Danish", "Dange Chowk", new BigInteger("987654321"), gym1);
		Member mem3=new Member(103, "Pradip", "Hinjewadi", new BigInteger("456321789"), gym2);
		Member mem4=new Member(104, "Kishor", "Aundh", new BigInteger("789654321"), null);

		List<Member> gym1MemberList=new ArrayList<>();
		gym1MemberList.add(mem1);
		gym1MemberList.add(mem2);
		gym1.setName(gym1MemberList);

		List<Member> gym2MemberList=new ArrayList<>();
		gym2MemberList.add(mem3);
		gym2.setName(gym2MemberList);

		gyms.add(gym1);
		gyms.add(gym2);

		members.add(mem1);
		members.add(mem2);
		members.add(mem3);
		members.add(mem4);
	}


	public static void main(String[] args) {



		GymService gymservice = new GymServiceImp();



		Scanner scan = new Scanner(System.in);
		int choice = 0;

		do {
			printMenu();
			System.out.println("Enter Choice:-");
			choice = scan.nextInt();

			switch(choice) {

			case 1:

				System.out.println("Enter Member Id:-");
				int memberId = scan.nextInt();
				Member member = gymservice.searchById(memberId);
				if(null == member) {
					System.out.println("Member with Member Id "+memberId+" not found.");
				}
				else {
					System.out.println("Please find details of member id "+memberId+
							"\nName : "+member.getName()+
							"\nAddress : "+member.getAddress()+
							"\nMobile Number : "+member.getMobile()+
							(null==member.getGym()?"\n\nGym Details are not available.":"\n\nGym Details\nGym Id : "+member.getGym().getGymId()+
							"\nGym Address : "+member.getGym().getGymAddress()+"\nExercises in the Gym : "+member.getGym().getExercises()));
				}
				break;


             case 2:
            	 
            	 System.out.println("Please enter equipment name to be search:-");
            	 String equipName = scan.next();
            	 List<Gym> gymList=gymservice.searchByName(equipName);
            	 if(null == gymList) {
            		 System.out.println("Equipment with name "+equipName+" not found.");
            	 }
            	 else {
            		 System.out.println("Euipment "+equipName+" found in "+gymList.size()+" gym. Please find details below.");

						for(Gym gym:gymList)
						{
							System.out.println("\nGym Id : "+gym.getGymId()+"\nGym Address : "+gym.getGymAddress());
						}
            	 }
            	 break;



			






			}

		}while(choice != 2);


	}

	private static void printMenu() {
		// TODO Auto-generated method stub
		System.out.println("*******************");
		System.out.println("Fitness Application");
		System.out.println("*******************\n");

		System.out.println("1. Search Member By Id");
		System.out.println("2. Search Equipment By Name");


	}
}





