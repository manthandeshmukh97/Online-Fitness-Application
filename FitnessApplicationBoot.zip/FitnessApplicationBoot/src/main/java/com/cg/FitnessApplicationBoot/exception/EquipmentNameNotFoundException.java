package com.cg.FitnessApplicationBoot.exception;

public class EquipmentNameNotFoundException extends Exception {
	
	public EquipmentNameNotFoundException() {
		
	}
	public EquipmentNameNotFoundException(String msg) {
		
		super(msg);
	}
}