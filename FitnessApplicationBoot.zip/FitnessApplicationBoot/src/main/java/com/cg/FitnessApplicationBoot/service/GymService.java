package com.cg.FitnessApplicationBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FitnessApplicationBoot.dao.GymDao;
import com.cg.FitnessApplicationBoot.dto.Equipment;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;

public interface GymService {

	
	public Member addMember(Member member);
	public List<Member> showAll();

//	public Equipment addEquipment(Equipment equipment);
	public List<Gym> searchByName(String name);
	public List<Member> searchByMemberId(int id);
}
