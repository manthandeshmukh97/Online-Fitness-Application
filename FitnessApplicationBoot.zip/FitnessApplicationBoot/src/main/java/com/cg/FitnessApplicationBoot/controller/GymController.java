package com.cg.FitnessApplicationBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;
import com.cg.FitnessApplicationBoot.service.GymService;

@RestController
@RequestMapping("/gym")
public class GymController {
	@Autowired
	GymService gymservice;


	/*@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
	//@GetMapping("checkname")
	public String getName(@PathVariable("uname") String mname, @RequestParam("prodid") String id)
	{
		System.out.println("hiiiii");
		return "Capgemini" +mname;
	}

	@RequestMapping(method=RequestMethod.POST, value="/checkname")
	public String getData(@RequestParam("prodId") int pid, @RequestParam("prodName") String pname, 
			@RequestParam("prodPrice") String pprice) {

		System.out.println(pid+" "+pname+" "+pprice);

		return "Welcome";		
	}*/


	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Member> addMemberO(@ModelAttribute("member") Member member) {

		Member memberOne = gymservice.addMember(member);		
		if(memberOne==null) {
			return new ResponseEntity("Gym Not Added ", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Member>(memberOne, HttpStatus.OK);

	}

	@RequestMapping(value="/show",method=RequestMethod.GET)

	public ResponseEntity<List<Member>> showAllMember(){
		List<Member> myList = gymservice.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("No Product To Show ", HttpStatus.NOT_FOUND);

		}

return new ResponseEntity<List<Member>>(myList,HttpStatus.OK);

	}

	
	@RequestMapping(value="/searchname",method=RequestMethod.GET)
public ResponseEntity<List<Gym>> searchEquipmentName(@RequestParam("ename") String name){
		List<Gym> myList = gymservice.searchByName(name);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Equipment Name Found ", HttpStatus.NOT_FOUND);

		}

return new ResponseEntity<List<Gym>>(myList,HttpStatus.OK);

	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public ResponseEntity<List<Member>> searchMemberId(@RequestParam("mid") int id){

		List<Member> myList = gymservice.searchByMemberId(id);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Member Id Found ", HttpStatus.NOT_FOUND);

		}

return new ResponseEntity<List<Member>>(myList,HttpStatus.OK);

	}
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Member> addAll(@ModelAttribute("member") Member memberOne){
	/*public ResponseEntity<Product> addAll(
			@RequestParam("id") int pid, 
			@RequestParam("name") String pname,
			@RequestParam("price") double pprice, 
			@RequestParam("desc") String desc,
			@RequestParam("inid") int inid,
			@RequestParam("inname") String inname){

		Inventory inventory = new Inventory();
		inventory.setId(inid);
		inventory.setName(inname);
		
		Product prod = new Product();
		prod.setId(pid);
		prod.setName(pname);
		prod.setPrice(pprice);
		prod.setDescription(desc);
		prod.setInventory(inventory);*/
		
		Member member = gymservice.addMember(memberOne);
		if(member==null) {
			return new ResponseEntity("No Name Found ", HttpStatus.NOT_FOUND);	
		}
		
		
			

		

return new ResponseEntity<Member>(member,HttpStatus.OK);

	}
	
	
	/*@RequestMapping(value="/search",method=RequestMethod.GET)
	public Product getProduct2(@RequestParam("id") int id){
		return productservice.getProduct(id);
	}


	@RequestMapping(value="/delete",method=RequestMethod.DELETE)
	public Product getDeleteProduct(@RequestParam("id") String id){
		int pid= Integer.parseInt(id);
		Product product = productservice.getProduct(pid);
		return productservice.deleteById(product);
	}*/


}
