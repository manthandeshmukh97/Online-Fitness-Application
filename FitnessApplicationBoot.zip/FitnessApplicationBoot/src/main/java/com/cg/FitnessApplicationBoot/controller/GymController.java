package com.cg.FitnessApplicationBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;
import com.cg.FitnessApplicationBoot.service.GymService;

@RestController
@RequestMapping("/gym")
public class GymController {
	@Autowired
	GymService gymservice;


	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for adding members, equipments and gym details
	 *@author mandeshm
	 *@param This method is used for adding members, equipments and gym details
	 *@return the members, equipments and gym details that we have added
	 */

	@RequestMapping(value="/add",method=RequestMethod.POST)
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<Member> addMemberO(@ModelAttribute("member") Member member) {

		Member memberOne = gymservice.addMember(member);		
		if(memberOne==null) {
			return new ResponseEntity("Gym Not Added ", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Member>(memberOne, HttpStatus.OK);

	}


	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding equipment name
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */

	@RequestMapping(value="/searchname",method=RequestMethod.GET)
	public ResponseEntity<List<Gym>> searchEquipmentName(@RequestParam("ename") String name){
		List<Gym> myList = gymservice.searchByName(name);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Equipment Name Found ", HttpStatus.NOT_FOUND);

		}

		return new ResponseEntity<List<Gym>>(myList,HttpStatus.OK);

	}

	
	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details using id
	 */
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public ResponseEntity<List<Member>> searchMemberId(@RequestParam("mid") int id){

		List<Member> myList = gymservice.searchByMemberId(id);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Member Id Found ", HttpStatus.NOT_FOUND);

		}

		return new ResponseEntity<List<Member>>(myList,HttpStatus.OK);

	}

	

	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for adding members, equipments and gym details
	 *@author mandeshm
	 *@param This method is used for adding members, equipments and gym details
	 *@return the members, equipments and gym details that we have added
	 */
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Member> addAll(@ModelAttribute("member") Member memberOne){


		Member member = gymservice.addMember(memberOne);
		if(member==null) {
			return new ResponseEntity("No Name Found ", HttpStatus.NOT_FOUND);	
		}

		return new ResponseEntity<Member>(member,HttpStatus.OK);

	}




}
