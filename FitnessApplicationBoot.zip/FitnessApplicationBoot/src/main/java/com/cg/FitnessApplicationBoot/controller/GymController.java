package com.cg.FitnessApplicationBoot.controller;

public class GymController {

}
