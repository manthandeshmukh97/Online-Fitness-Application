package com.cg.FitnessApplicationBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.FitnessApplicationBoot")
public class FitnessApplicationBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessApplicationBootApplication.class, args);
		System.out.println("Fitness Application");
	}

}
