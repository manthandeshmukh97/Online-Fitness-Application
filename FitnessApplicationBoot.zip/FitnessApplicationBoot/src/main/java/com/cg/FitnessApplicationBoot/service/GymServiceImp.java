package com.cg.FitnessApplicationBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FitnessApplicationBoot.dao.GymDao;
import com.cg.FitnessApplicationBoot.dto.Equipment;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;
@Service
public class GymServiceImp implements GymService {

	
	@Autowired
	GymDao gymdao;
	

	@Override
	public Gym addGym(Gym gym) {
		// TODO Auto-generated method stub
		return gymdao.save(gym);
	}


	@Override
	public List<Gym> searchByName(String name) {
		// TODO Auto-generated method stub
		return gymdao.findByName(name);
	}

	@Override
	public Member searchByMemberId(int id) {
		// TODO Auto-generated method stub
		return gymdao.findById(id);
	}

}
