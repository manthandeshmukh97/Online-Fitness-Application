package com.cg.FitnessApplicationBoot.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FitnessApplicationBoot.dao.GymDao;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;
@Service
public class GymServiceImp implements GymService {

	static final Logger logger = Logger.getLogger(GymServiceImp.class); 	

	@Autowired
	GymDao gymdao;
	

	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for adding members, equipments and gym details
	 *@author mandeshm
	 *@param This method is used for adding members, equipments and gym details
	 *@return the members, equipments and gym details that we have added
	 */
	@Override
	public Member addMember(Member member) {
		
		PropertyConfigurator.configure("D:\\Java Programs2\\FitnessApplicationBoot\\src\\main\\resources\\templates\\log4j.properties"); 
		logger.info("Member added successful");
		// TODO Auto-generated method stub
		return gymdao.save(member);
	}


	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding equipment name
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */
	@Override
	public List<Gym> searchByName(String name) {
		
		PropertyConfigurator.configure("D:\\Java Programs2\\FitnessApplicationBoot\\src\\main\\resources\\templates\\log4j.properties"); 
		logger.info("Equipment Search successful");
		// TODO Auto-generated method stub
		return gymdao.findByName(name);
	}

	
	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details using id
	 */
	@Override
	public List<Member> searchByMemberId(int id) {
		
		PropertyConfigurator.configure("D:\\Java Programs2\\FitnessApplicationBoot\\src\\main\\resources\\templates\\log4j.properties"); 
		logger.info("Member Id Search successful");
		// TODO Auto-generated method stub
		return gymdao.findById(id);
	}
	

	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for showing all the details
	 *@author mandeshm
	 *@param This method is used for showing all the details that we have added
	 *@return the member, gym and equipments details
	 */
	@Override
	public List<Member> showAll() {
		// TODO Auto-generated method stub
		return gymdao.findAll();
	}



}
