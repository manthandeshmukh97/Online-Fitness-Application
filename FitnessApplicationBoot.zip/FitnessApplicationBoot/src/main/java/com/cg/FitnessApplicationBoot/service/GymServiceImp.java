package com.cg.FitnessApplicationBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FitnessApplicationBoot.dao.GymDao;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;
@Service
public class GymServiceImp implements GymService {

	
	@Autowired
	GymDao gymdao;
	

	@Override
	public Member addMember(Member member) {
		// TODO Auto-generated method stub
		return gymdao.save(member);
	}


	@Override
	public List<Gym> searchByName(String name) {
		// TODO Auto-generated method stub
		return gymdao.findByName(name);
	}

	@Override
	public List<Member> searchByMemberId(int id) {
		// TODO Auto-generated method stub
		return gymdao.findById(id);
	}
	
	@Override
	public List<Member> showAll() {
		// TODO Auto-generated method stub
		return gymdao.findAll();
	}


	


	/*@Override
	public Equipment addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		return gymdao.save(equipment);
	}*/

}
