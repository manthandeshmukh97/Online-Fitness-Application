package com.cg.FitnessApplicationBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.FitnessApplicationBoot.dto.Equipment;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;

public interface GymDao extends JpaRepository<Member, Integer> {
	
	@Query
	public List<Gym> findByName(String name);
	public List<Member> findById(int id);

}
