package com.cg.FitnessApplicationBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.FitnessApplicationBoot.dto.Equipment;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;

public interface GymDao extends JpaRepository<Member, Integer> {
	
	/**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding equipment name
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */
    @Query("select g from Gym g, in(g.equipments)e where e.name=?1")
	public List<Gym> findByName(String name);
    
    /**
	 * Last Modified On 24/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details and gym details using member id
	 */
    @Query("select m from Member m where m.id=?1")
	public List<Member> findById(int id);

}
