package com.cg.FitnessApplicationBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.FitnessApplicationBoot.dto.Equipment;
import com.cg.FitnessApplicationBoot.dto.Gym;
import com.cg.FitnessApplicationBoot.dto.Member;

public interface GymDao extends JpaRepository<Member, Integer> {
	
    @Query("select g from Gym g, in(g.equipments)e where e.name=?1")
	public List<Gym> findByName(String name);
    @Query("select m from Member m where m.id=?1")
	public List<Member> findById(int id);

}
