package com.cg.fitnessappmvcusingjavaconfig.exception;

public class MemberNotSaveIntoDatabase extends Exception {
	
	public MemberNotSaveIntoDatabase() {
		
	}
	public MemberNotSaveIntoDatabase(String msg) {
		
		super(msg);
	}
}
