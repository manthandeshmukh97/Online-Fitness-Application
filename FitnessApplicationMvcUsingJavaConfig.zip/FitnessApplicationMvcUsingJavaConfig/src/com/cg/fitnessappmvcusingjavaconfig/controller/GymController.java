package com.cg.fitnessappmvcusingjavaconfig.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;
import com.cg.fitnessappmvcusingjavaconfig.exception.EquipmentNameNotFoundException;
import com.cg.fitnessappmvcusingjavaconfig.exception.MemberNotSaveIntoDatabase;
import com.cg.fitnessappmvcusingjavaconfig.service.GymService;

@Controller
public class GymController {

	@Autowired
	GymService gymservice;
	Gym gymOne;

	@GetMapping("login")
	public String loginPage()
	{
		return "listpage";
	}

	@GetMapping("addgym")
	public ModelAndView addGym(@ModelAttribute("gym") Gym gymOne) {
		return new ModelAndView("addgym");
	}

	@PostMapping("addgym")
	public ModelAndView addGymOne(@ModelAttribute("gym")  Gym gymOne) {
		this.gymOne=gymOne;
		return new ModelAndView("successgym","key",gymOne);
	}

	@GetMapping("addequipn")
	public ModelAndView addEquipment(@ModelAttribute("equipmentO") Equipment equ) {
		return new ModelAndView("addequipment", "key", equ); 
	}

	@PostMapping("addequip")
	public ModelAndView addEqu(@RequestParam("equipmentId") int equipmentId,@RequestParam("equipmentName") String equipmentName,
			@RequestParam("equipmentDescription") String equipmentDescription){
		Equipment equ = new Equipment();
		equ.setId(equipmentId);
		equ.setName(equipmentName);
		equ.setDescription(equipmentDescription);

		List<Equipment> equipmentList = new ArrayList<Equipment>();
		equipmentList.add(equ);

		Gym gymTwo = new Gym();

		gymTwo.setId(gymOne.getId());
		gymTwo.setAddress(gymOne.getAddress());
		gymTwo.setExercises(gymOne.getExercises());

		gymTwo.setEquipmentName(equipmentList);
		Gym gym = gymservice.addGym(gymTwo);
		return new ModelAndView("successequipment","key",gym);
	}

	@GetMapping("success")
	public String homePage()
	{
		return "listpage";

	}


	@GetMapping("addmember")
	public ModelAndView getAddMember(@ModelAttribute("member") Member memberOne) {
		Member mbrOne = new Member();
		return new ModelAndView("addmember","listOfExercises",mbrOne );
	}

	@GetMapping("showmember")
	public ModelAndView showMember(@ModelAttribute("member") Member memberOne) {

		Member myMember = gymservice.addMember(memberOne);
		return new ModelAndView("show", "showmember", myMember);

	}

	@PostMapping("addmember")
	public ModelAndView addMember(@ModelAttribute("member") Member memberOne) {
		Member memberTwo =  gymservice.addMember(memberOne);

		return new ModelAndView("successmember","mbr",memberTwo);
	}

	@GetMapping("searchmember")
	public ModelAndView getSearchMember() {
		return new ModelAndView("SearchMember");

	}
	@PostMapping("sucesssearch")
	public ModelAndView SearchMember(@ModelAttribute("member") Member member,@RequestParam("id") int id)
	{
		List<Member> memberList=null;

		try {

			memberList=gymservice.searchByMemberId(id);
		}
		catch(Exception e) {
			return new ModelAndView("error2");
		}
		return new ModelAndView("sucesssearch","key",memberList);
	}


	@GetMapping("searchequipment")
	public ModelAndView showEquipment() {

		return new ModelAndView("SearchEquipment");
	}
	
	@PostMapping("detailsByName")
	public ModelAndView searchEquipmentbyName(@ModelAttribute("equipment") Equipment eqp,@RequestParam("nameRef") String name) {
try {
		List<Gym> gymOne = gymservice.searchByName(name);
   
}catch(Exception e) {
	return new ModelAndView("error3");
}
		

		return new ModelAndView("detailsByName", "key", gymOne);
	}

	/*@PostMapping("detailsByName")
	public ModelAndView searchEquipmentbyName(@ModelAttribute("gym")Gym gym, @RequestParam("nameRef") String name) {

		List<Gym> listOfEquipment = gymservice.searchByName(name);
		return new ModelAndView("detailsByName", "key", listOfEquipment);
	}*/


	@ExceptionHandler(MemberNotSaveIntoDatabase.class)
	public ModelAndView MemberNotSaveIntoDatabase(MemberNotSaveIntoDatabase u) {

		ModelAndView model = new ModelAndView("error/errorc");


		model.addObject("errmsgkey", u.getMessage());

		return model;

	}
}
