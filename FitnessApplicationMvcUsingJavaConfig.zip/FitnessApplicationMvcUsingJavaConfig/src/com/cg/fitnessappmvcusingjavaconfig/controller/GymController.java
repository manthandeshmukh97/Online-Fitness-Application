package com.cg.fitnessappmvcusingjavaconfig.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;
import com.cg.fitnessappmvcusingjavaconfig.service.GymService;

@Controller
public class GymController {
	
@Autowired
GymService gymservice;

@GetMapping("login")
public String loginPage()
{
	return "listpage";
}

@PostMapping("checkLogin")
public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
	// System.out.println("check login");
	 if(user.equals("admin") && pass.equals("123")) {
		 return "listpage";
	 }else {
		 return "error";
	 }
	// return null;
}

@GetMapping("addgym")
public ModelAndView getAddGym(@ModelAttribute("gym") Gym gymOne) {
	 List<String> listOfExercises=new ArrayList<>();
	 listOfExercises.add("Dumbell Curl");
	 listOfExercises.add("Shoulder Press");
	 listOfExercises.add("Incline Dumbell Fly");
	// map.put("cato",listOfCategory);,Map<String,Object> map
	 return new ModelAndView("addgym","listOfExercises",listOfExercises );
}

@GetMapping("showgym")
public ModelAndView showGym(@ModelAttribute("gym")  Gym gymOne) {
	Gym myProducts = gymservice.addGym(gymOne);
	 return new ModelAndView("showAll", "showgym", myProducts);
}


@PostMapping("addgym")
public ModelAndView addGym(@ModelAttribute("gym")  Gym gymOne) {
//	 System.out.println(pro);
	Gym gymTwo =  gymservice.addGym(gymOne);
	 return new ModelAndView("successgym","key",gymTwo);
}

@GetMapping("addequipn")
public ModelAndView getAddEquipment(@ModelAttribute("equipment") Equipment equipmentOne) {
	List<String> listOfEquipment = new ArrayList<>();
	listOfEquipment.add("Bench Press");
	listOfEquipment.add("Smith Machine");
	listOfEquipment.add("Squat Rack");
	 return new ModelAndView("addequipment","listofequipments",listOfEquipment );

}

@GetMapping("showequipment")
public ModelAndView showEquipment(@ModelAttribute("equipment") Equipment equipmentOne) {
	
	Equipment myEquipment = gymservice.addEquipment(equipmentOne);
	return new ModelAndView("show", "showgym", myEquipment);

}

@PostMapping("addequip")
public ModelAndView addEquipment(@ModelAttribute("equipment") Equipment equipmentOne) {
Equipment equipmentTwo =  gymservice.addEquipment(equipmentOne);

return new ModelAndView("successequipment","equip",equipmentTwo);
}

@GetMapping("addmember")
public ModelAndView getAddMember(@ModelAttribute("member") Member memberOne) {
	Member mbrOne = new Member();
	// map.put("cato",listOfCategory);,Map<String,Object> map
	 return new ModelAndView("addmember","listOfExercises",mbrOne );
}

@GetMapping("showmember")
public ModelAndView showMember(@ModelAttribute("member") Member memberOne) {
	
	Member myMember = gymservice.addMember(memberOne);
	return new ModelAndView("show", "showmember", myMember);

}

@PostMapping("addmember")
public ModelAndView addMember(@ModelAttribute("member") Member memberOne) {
Member memberTwo =  gymservice.addMember(memberOne);

return new ModelAndView("successmember","mbr",memberTwo);
}
}
