package com.cg.fitnessappmvcusingjavaconfig.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fitnessappmvcusingjavaconfig.dto.Member;
import com.cg.fitnessappmvcusingjavaconfig.service.GymService;

@Controller
public class GymController {
	
@Autowired
GymService gymservice;

@GetMapping("login")
public String loginPage()
{
	return "mylogin";
}

@PostMapping("checkLogin")
public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
	// System.out.println("check login");
	 if(user.equals("admin") && pass.equals("123")) {
		 return "listpage";
	 }else {
		 return "error";
	 }
	// return null;
}

@GetMapping("addpage")
public ModelAndView getAddMember(@ModelAttribute("membr") Member member) {
	 List<String> listOfEquipments=new ArrayList<>();
	 listOfEquipments.add("Bench Press");
	 listOfEquipments.add("Smith Machine");
	 listOfEquipments.add("Leg Press");
	// map.put("cato",listOfCategory);,Map<String,Object> map
	 return new ModelAndView("addproduct", "cato", listOfEquipments);
}

@GetMapping("showpage")
public ModelAndView showMember(@ModelAttribute("membr") Member member) {
	List<Member> myProducts = gymservice.addMember(member);
	 return new ModelAndView("showAll", "showproduct", myProducts);
}


@PostMapping("addproduct")
public ModelAndView addMember(@ModelAttribute("prod") Member member) {
//	 System.out.println(pro);
	Member memberOne= gymservice.addMember(member);
	 return new ModelAndView("success","key",memberOne);
}



}
