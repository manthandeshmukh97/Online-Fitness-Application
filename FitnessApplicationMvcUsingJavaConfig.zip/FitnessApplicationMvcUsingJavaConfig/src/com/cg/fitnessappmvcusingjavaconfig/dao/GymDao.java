package com.cg.fitnessappmvcusingjavaconfig.dao;

import java.util.List;

import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;

public interface GymDao {
	
	public Member save(Member member);
	public Gym save(Gym gym1);
	public Equipment save(Equipment equipment);
	public Member findById(int id);
    public List<Gym> findByName(String equipmentName);

}
