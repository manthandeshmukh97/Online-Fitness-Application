package com.cg.fitnessappmvcusingjavaconfig.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;

@Repository
public class GymDaoImp implements GymDao {

	private static List<Member> members;
	private static List<Equipment> equips;
	private static List<Gym> gyms;
	@PersistenceContext
	EntityManager em;
	
	/**
	 * Last Modified On 22/05/2019
	 *The following method is used for adding gym 
	 *@author mandeshm 
	 *@param This method is used for adding gym
	 *@return the gym that we have added
	 */

	public Gym save(Gym gym) {

		Gym gymOne = findByIdOne(gym.getId());
		if(gymOne==null) {
			em.persist(gym);
			em.flush();

		}
		else
		{
			Equipment equ = new Equipment();
			equ.setId(gym.getEquipmentName().get(0).getId());
			equ.setName(gym.getEquipmentName().get(0).getName());
			equ.setDescription(gym.getEquipmentName().get(0).getDescription());
			equ.setGym(gymOne);
			em.merge(equ);
			em.flush();
		}

		return gym;
	}


	public Gym findByIdOne(Integer gymId) {

		Gym gymThree = null;
		try
		{
			Query query = em.createQuery("from Gym where id=:gymId");
			query.setParameter("gymId", gymId);
			gymThree= (Gym) query.getSingleResult();
		}catch(NoResultException e)
		{
			System.out.println("no data found");
		}
		return gymThree;
	}

	public Equipment save(Equipment equipment) {

		em.persist(equipment);
		em.flush();
		return equipment;
	}
	
	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding members 
	 *@author mandeshm
	 *@param This method is used for adding members and accepts all the member details.
	 *@return the member that we have added
	 */

	public Member save(Member member)  {



		int gym_id = member.getGym().getId();
		Query queryOne  = em.createQuery("select a from Gym a where gym_id= :gym_id"); 
		List<Gym> gym = queryOne.setParameter("gym_id", gym_id).getResultList(); 

		if(!(gym.isEmpty())) { 

			em.persist(member); 

			em.flush();
		} 

		return member;
	}	

	

	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding equipment name
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */
	public List<Gym> findByName(String equipName){
		//List<Equipment> equipmentList = new ArrayList<Equipment>();
		List<Gym> gymList = new ArrayList<Gym>();
		List<Gym> gymListOne = new ArrayList<Gym>();
		int gym_id=0;
System.out.println(equipName);
		Query query = em.createQuery("select a from Equipment a where equipName= :equipName");
		List<Equipment> gym = query.setParameter("equipName", equipName).getResultList(); 
		
		for(Equipment eq:gym)
		{
			gym_id=eq.getGym().getId();
			System.out.println(gym_id);
		}
		
		Query queryOne = em.createQuery("select s from Gym s where gym_id= :gym_id");
		List<Gym> gymOne = queryOne.setParameter("gym_id", gym_id).getResultList(); 
		
	
		return gymOne;
		
	}

	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details using id
	 */

	public List<Member> findByMemberId(int id)
	{

		Query query  = em.createQuery("Select a From Member a where member_id= :id");
        List<Member> depts=query.setParameter("id", id).getResultList();
        return depts;
	}





}
