package com.cg.fitnessappmvcusingjavaconfig.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;

@Repository
public class GymDaoImp implements GymDao {
	
	private static List<Member> members = new ArrayList<Member>();
	private static List<Gym> gyms=new ArrayList<Gym>();
	private static List<Equipment> equipments = new ArrayList<Equipment>();

	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding members 
	 *@author mandeshm
	 *@param This method is used for adding members and accepts all the member details.
	 *@return the member that we have added
	 */
    public Member save(Member member) {

		members.add(member);
		return member;

	}


	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding gym 
	 *@author mandeshm 
	 *@param This method is used for adding gym
	 *@return the gym that we have added
	 */
	public Gym save(Gym gym1) {
		// TODO Auto-generated method stub

		gyms.add(gym1);
		return gym1;
	}

	
	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding equipments into the gym 
	 *@author mandeshm
	 *@param This method is used for adding equipments
	 *@return the equipments that we have added
	 */
	public Equipment save(Equipment equipment) {

		equipments.add(equipment);

		return equipment;
	}


	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details using id
	 */
	public Member findById(int id)  {
	

		for (Member member : members) {
			if(member.getId()==id)


				return member;
		}
		return null;

	


}
	
	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding equipment name
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */
	public List<Gym> findByName(String equipmentName) {
		List<Gym> gymWithEquip=new ArrayList<Gym>();
		


			for(Gym gym: gyms)
			{
				for(Equipment equip : gym.getEquipmentName())
				{
					if(equip.getName().equals(equipmentName))
					{
						gymWithEquip.add(gym);
					}
				}
			}

			return gymWithEquip;
		

	}





}
