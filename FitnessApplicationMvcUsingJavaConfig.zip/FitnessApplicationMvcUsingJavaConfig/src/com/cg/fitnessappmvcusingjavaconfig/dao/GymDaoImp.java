package com.cg.fitnessappmvcusingjavaconfig.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;

@Repository
public class GymDaoImp implements GymDao {

	private static List<Member> members;
	private static List<Equipment> equips;
	private static List<Gym> gyms;
	@PersistenceContext
	EntityManager em;



	public Member save(Member member)  {



		int gym_id = member.getGym().getId();
		Query queryOne  = em.createQuery("select a from Gym a where gym_id= :gym_id"); 
		List<Gym> gym = queryOne.setParameter("gym_id", gym_id).getResultList(); 

		if(!(gym.isEmpty())) { 
		
			em.persist(member); 
			//em.merge(vehicle); 
		
			em.flush();
		} 

		return member;
	}


	public Equipment save(Equipment equipment) {

		em.persist(equipment);
	    em.flush();
		return equipment;
	}




	public Gym save(Gym gym) {
		
		em.persist(gym);
		em.flush();
		return gym;
	}

	public Member findById(int id)
	{ 	


		Member member = new Member();
		TypedQuery<Member> query = em.createQuery("select m from Member m where m.id=?", Member.class);
		query.setParameter(1, id);
		member = query.getSingleResult();
		return member;
	}

	public List<Gym> findByName(String equipName){

		List<Gym> gymList = new ArrayList<Gym>();

		TypedQuery<Gym> query = em.createQuery("select g from Gym g, in(g.equipmentName)e where e.name=?",Gym.class);
		query.setParameter(1,equipName);
		gymList = query.getResultList();
		return gymList;



	}





}
