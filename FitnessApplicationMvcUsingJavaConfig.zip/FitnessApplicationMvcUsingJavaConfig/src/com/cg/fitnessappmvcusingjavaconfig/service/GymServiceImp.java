package com.cg.fitnessappmvcusingjavaconfig.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fitnessappmvcusingjavaconfig.dao.GymDao;
import com.cg.fitnessappmvcusingjavaconfig.dao.GymDaoImp;
import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;
@Service
public class GymServiceImp implements GymService {

	@Autowired
GymDao repository;

	
	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding members 
	 *@author mandeshm
	 *@param This method is used for adding members
	 *@return the member that we have added
	 */
	public Member addMember(Member member) {
		// TODO Auto-generated method stub
		return repository.save(member);
	}

	


	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding gym 
	 *@author mandeshm 
	 *@param This method is used for adding gym
	 *@return the gym that we have added
	 */
	public Gym addGym(Gym gym1) {

		// TODO Auto-generated method stub
		return repository.save(gym1);
	}

	

	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding equipments into the gym 
	 *@author mandeshm
	 *@param This method is used for adding equipments
	 *@return the equipments that we have added
	 */
	public Equipment addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
	
		
		return repository.save(equipment);
	}


	

		/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *and this method will search the member id and if id is not available then it will throw MemberNotFoundException 
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details using id
	 */
	public Member searchById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}


	


	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding equipment name and if equipment name is not searched then it will throw EquipmentNameNotFoundException 
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */
	public List<Gym> searchByName(String equipmentName)  {
		
		// TODO Auto-generated method stub

		return repository.findByName(equipmentName);
	}









}
