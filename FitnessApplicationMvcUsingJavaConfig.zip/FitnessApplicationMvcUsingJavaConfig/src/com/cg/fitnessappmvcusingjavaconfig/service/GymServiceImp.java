package com.cg.fitnessappmvcusingjavaconfig.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fitnessappmvcusingjavaconfig.dao.GymDao;
import com.cg.fitnessappmvcusingjavaconfig.dao.GymDaoImp;
import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;
@Service
@Transactional
public class GymServiceImp implements GymService {
@Autowired
	GymDao gymDao = new GymDaoImp();
	
	public Member addMember(Member member)  {
		// TODO Auto-generated method stub
		return gymDao.save(member);
	}

	
	public Member searchById(int id){
		// TODO Auto-generated method stub
		return gymDao.findById(id);
	}

	
	


	public Gym addGym(Gym gym) {
		// TODO Auto-generated method stub
		return gymDao.save(gym);
	}


	public Equipment addEquipment(Equipment equipment) {
		// TODO Auto-generated method stub
		 return gymDao.save(equipment);
	}
	
	public List<Gym> searchByName(String equipName) {
		// TODO Auto-generated method stub
		return gymDao.findByName(equipName);
	}







}
