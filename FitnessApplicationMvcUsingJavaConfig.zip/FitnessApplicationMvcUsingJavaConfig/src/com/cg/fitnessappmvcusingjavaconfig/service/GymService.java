package com.cg.fitnessappmvcusingjavaconfig.service;

import java.util.List;

import com.cg.fitnessappmvcusingjavaconfig.dto.Equipment;
import com.cg.fitnessappmvcusingjavaconfig.dto.Gym;
import com.cg.fitnessappmvcusingjavaconfig.dto.Member;

public interface GymService {
	
	public Member addMember(Member member);
	public Gym addGym(Gym gym1);
	public Equipment addEquipment(Equipment equipment);
    public Member searchById(int id);
	public List<Gym> searchByName(String equipmentName);

}
