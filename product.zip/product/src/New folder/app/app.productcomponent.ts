import { Component, OnInit } from '@angular/core';
import { ProductService } from './app.productservice';
import { Product } from './app.product';
@Component({

    selector: 'prod-app',
    templateUrl: 'app.product.html'

})

export class ProductComponent implements OnInit {

    products:Product[];
constructor(private proservice:ProductService){}

ngOnInit(){

    this.proservice.getAllProduct().subscribe((data:Product[]) => this.products=data);
}

 }