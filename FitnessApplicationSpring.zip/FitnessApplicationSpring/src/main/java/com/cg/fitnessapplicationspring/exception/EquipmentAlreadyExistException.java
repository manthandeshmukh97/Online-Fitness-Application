/**
 * Last Modified On 15/05/2019
 * EquipmentAlreadyExistException is thrown whenever equipment with same id is going to be add
 *@author mandeshm
 *
 */

package com.cg.fitnessapplicationspring.exception;



	public class EquipmentAlreadyExistException extends Exception {
		
		public EquipmentAlreadyExistException() {
			
		}
		public EquipmentAlreadyExistException(String msg) {
			
			super(msg);
		}
	}
