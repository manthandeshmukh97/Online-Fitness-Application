/**
 * Last Modified On 15/05/2019
 *Main Class of the project, inputs and outputs of the project are done here.  
 *@author mandeshm
 *
 */

package com.cg.fitnessapplicationspring.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.fitnessapplicationspring.config.JavaConfig;
import com.cg.fitnessapplicationspring.dto.Equipment;
import com.cg.fitnessapplicationspring.dto.Gym;
import com.cg.fitnessapplicationspring.dto.Member;
import com.cg.fitnessapplicationspring.exception.EquipmentAlreadyExistException;
import com.cg.fitnessapplicationspring.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationspring.exception.MemberNotFoundException;
import com.cg.fitnessapplicationspring.service.GymService;
import com.cg.fitnessapplicationspring.service.GymServiceImp;




@Component
public class FitnessApplicationSpring {

	@Autowired
	GymService service;
	static GymService gymservice;
	@PostConstruct
	public void init() {
		gymservice = this.service;
	}
	public static void main(String[] args) {



		AnnotationConfigApplicationContext aca = new AnnotationConfigApplicationContext(JavaConfig.class);

		gymservice =  (GymService) aca.getBean("gymservice");
		Member memberO = (Member) aca.getBean("memberOne");
		Equipment equip = (Equipment) aca.getBean("equipmentOne");
		Gym gym2 = (Gym) aca.getBean("gymOne");
		Scanner scan = new Scanner(System.in);
		int choice = 0;

		do {
			printMenu();
			System.out.println("Enter Choice:-");
			choice = scan.nextInt();

			switch(choice) {
			/**
			 * Last Modified On 15/05/2019
			 *this case is used for adding gym details and equipment details  
			 *you can add number of equipments into the one gym.
			 *@author mandeshm
			 */

			case 1:

				List<Equipment> equ = new ArrayList<Equipment>();
				List<Member> members=new ArrayList<Member>();


				//Enter all the gym details

				System.out.println("Enter Gym Id:-");
				int gymId = scan.nextInt();
				System.out.println("Enter Gym Address:-");
				String gymAddress = scan.next();
				System.out.println("Enter Gym Exercises:-");
				String exercise = scan.next();

				gym2.setId(gymId);
				gym2.setAddress(gymAddress);
				gym2.setExercises(exercise);
				System.out.println("Gym Added...Your Id Is:-"+gym2.getId());//Display the gym id that we have added.



				char ch;
				do {

					//Enter all the equipment details

					System.out.println("Enter Equipment Id:-");
					int eid = scan.nextInt();
					System.out.println("Enter Equipment Name:-");
					String ename = scan.next();
					System.out.println("Enter Equipment Description:-");
					String edesc = scan.next();


					equip.setId(eid);
					equip.setName(ename);
					equip.setDescription(edesc);
					gym2.setEquipmentName(equ);

					System.out.println("Equipment Added...Your Id Is:-"+equip.getId());//Display the equipment id that we have added.
					
					
						equ.add(equip);
					System.out.println(gymservice.addGym(gym2));

					


					System.out.println("Do you want to assign another equipment??  Y/N");
					ch=scan.next().charAt(0);
					System.out.println();
				}while(ch=='Y'||ch=='y');


				break;

				/**
				 * Last Modified On 15/05/2019
				 *this case is used for adding member details into the particular gym id  
				 *you can add number of members into the one gym.
				 *@author mandeshm
				 */
			case 2:


				System.out.println("Enter Gym Id:-");
				int gymid = scan.nextInt();
				char ch1 = 0;




				do {

					//Enter all the member details



					System.out.println("Enter Member Id:-");
					int id = scan.nextInt();
					System.out.println("Enter Member Name:-");
					String name = scan.next();
					System.out.println("Enter Member Address:-");
					String address = scan.next();
					System.out.println("Enter Member Mobile No:-");
					BigInteger mobile = scan.nextBigInteger();


					gym2.getId();
					gym2.getAddress();
					gym2.getExercises();

					memberO.setId(id);
					memberO.setName(name);
					memberO.setAddress(address);
					memberO.setMobile(mobile);
					memberO.setGym(gym2);

					System.out.println("Member Added...Your Id Is:-"+memberO.getId());//Display the member id.


					System.out.println(gymservice.addMember(memberO));



					System.out.println("Do you want to assign another member??  Y/N");
					ch1=scan.next().charAt(0);
					System.out.println();
				}while(ch1=='Y'||ch1=='y');



				break;



				/**
				 * Last Modified On 15/05/2019
				 *this case is used for searching member into the particular gym  
				 *if member is available in the gym then it will show all the details otherwise throws MemberNotFoundException
				 *@author mandeshm
				 */

			case 3:

				System.out.println("Enter Member Id:-");//We have to enter member id that we have previously added
				int memberId = scan.nextInt();
				Member member;
				try {
					member = gymservice.searchById(memberId);
					//					if(null == member) 



					System.out.println("\n**Member Details Are**\n");//Provides member details according to the member id
					System.out.println("Member Id:-"+member.getId());
					System.out.println("Member Name:-"+member.getName());
					System.out.println("Member Address:-"+member.getAddress());
					System.out.println("Member Mobile:-"+member.getMobile());
					System.out.println("\n**Gym Details Are**");//Provides gym details according to the member id
					System.out.println("Gym Id:-"+member.getGym().getId());
					System.out.println("Gym Address:-"+member.getGym().getAddress());
					System.out.println("Gym Exercises:-"+member.getGym().getExercises());


				} catch (MemberNotFoundException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
				}
				//				System.out.println("Member with Member Id "+memberId+" not found.");

				break;

				/**
				 * Last Modified On 15/05/2019
				 *this case is used for searching equipment into the particular gym  
				 *if equipment is available in the gym then it will show all the details otherwise throws EquipmentNameNotFoundException
				 *@author mandeshm
				 */

			case 4:

				System.out.println("Please enter equipment name to be search:-");
				String equipName = scan.next();
				List<Gym> gymList;

				try {
					gymList = gymservice.searchByName(equipName);


					//System.out.println("Equipment "+equipName+" found in "+gymList.size()+" gym. Please find details below.");

					for(Gym gym:gymList)
					{
						System.out.println("\nGym Id : "+gym.getId()+"\nGym Address : "+gym.getAddress());//Displays gym details according to the equipment name
					}
				}
				catch (EquipmentNameNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}

				break;

			case 5:
				System.exit(choice);
				break;
			default:
				System.out.println("Wrong choice..");
				break;








			}

		}while(choice != 6);



	}

	private static void printMenu() {
		// TODO Auto-generated method stub
		System.out.println("*******************");
		System.out.println("Fitness Application");
		System.out.println("*******************\n");

		System.out.println("1. Add Gym and Equipment");
		System.out.println("2. Add Member");
		System.out.println("3. Search Member By Id");
		System.out.println("4. Search Equipment By Name");
		System.out.println("5. Exit");


	}

}
