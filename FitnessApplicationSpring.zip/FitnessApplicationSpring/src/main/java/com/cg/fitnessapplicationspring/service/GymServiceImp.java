/**
 * GymService implementation by @author manthan deshmukh
 *
 *
 */

package com.cg.fitnessapplicationspring.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fitnessapplicationspring.dao.GymDao;
import com.cg.fitnessapplicationspring.dao.GymDaoImp;
import com.cg.fitnessapplicationspring.dto.Equipment;
import com.cg.fitnessapplicationspring.dto.Gym;
import com.cg.fitnessapplicationspring.dto.Member;
import com.cg.fitnessapplicationspring.exception.EquipmentAlreadyExistException;
import com.cg.fitnessapplicationspring.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationspring.exception.MemberNotFoundException;


@Service("gymservice")
public class GymServiceImp implements GymService {

	@Autowired
	GymDaoImp repository;

	
	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding members 
	 *@author mandeshm
	 *@param This method is used for adding members
	 *@return the member that we have added
	 */
	public Member addMember(Member member) {
		// TODO Auto-generated method stub
		return repository.save(member);
	}

	


	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding gym 
	 *@author mandeshm 
	 *@param This method is used for adding gym
	 *@return the gym that we have added
	 */
	public Gym addGym(Gym gym1) {

		// TODO Auto-generated method stub
		return repository.save(gym1);
	}

	

	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for adding equipments into the gym 
	 *@author mandeshm
	 *@param This method is used for adding equipments
	 *@return the equipments that we have added
	 */
	public Equipment addEquipment(Equipment equipment) throws EquipmentAlreadyExistException {
		// TODO Auto-generated method stub
		Equipment equipment2 = repository.save(equipment);
		if(equipment2==null)
		throw new EquipmentAlreadyExistException("Equipment Already Exist");
		
		return equipment2;
	}


	

		/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding the member id that we have added previously  
	 *and this method will search the member id and if id is not available then it will throw MemberNotFoundException 
	 *@author mandeshm
	 *@param This method is used for finding member by id
	 *@return the member details using id
	 */
	public Member searchById(int id) throws MemberNotFoundException {
		// TODO Auto-generated method stub
		if(repository.findById(id)==null)
			throw new MemberNotFoundException("Member Is  Not Available");
		return repository.findById(id);
	}


	


	/**
	 * Last Modified On 11/05/2019
	 *The following method is used for finding equipment name and if equipment name is not searched then it will throw EquipmentNameNotFoundException 
	 *@author mandeshm
	 *@param This method is used for finding equipment name using equipment name that we have added already
	 *@return the gym details in which that equipment is available
	 */
	public List<Gym> searchByName(String equipmentName) throws EquipmentNameNotFoundException {
		
		// TODO Auto-generated method stub
		if(repository.findByName(equipmentName).isEmpty())
			throw new EquipmentNameNotFoundException("Equipment Is Not Available.");
		return repository.findByName(equipmentName);
	}










}
