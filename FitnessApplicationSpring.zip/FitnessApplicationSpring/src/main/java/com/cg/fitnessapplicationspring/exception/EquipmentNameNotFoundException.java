/**
 * Last Modified On 15/05/2019
 * EquipmentNameNotFoundException is thrown whenever equipment is searched and data is not found
 *@author mandeshm
 *
 */
package com.cg.fitnessapplicationspring.exception;

public class EquipmentNameNotFoundException extends Exception {
	
	public EquipmentNameNotFoundException() {
		
	}
	public EquipmentNameNotFoundException(String msg) {
		
		super(msg);
	}
}