package com.cg.fitnessapplicationspring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cg.fitnessapplicationspring")
public class JavaConfig {
	

}
