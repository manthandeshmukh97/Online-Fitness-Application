

package com.cg.fitnessapplicationspring.service;

import java.util.List;

import com.cg.fitnessapplicationspring.dto.Equipment;
import com.cg.fitnessapplicationspring.dto.Gym;
import com.cg.fitnessapplicationspring.dto.Member;
import com.cg.fitnessapplicationspring.exception.EquipmentAlreadyExistException;
import com.cg.fitnessapplicationspring.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationspring.exception.MemberNotFoundException;



public interface GymService {
	public Member addMember(Member member);
	public Gym addGym(Gym gym1);
	public Equipment addEquipment(Equipment equipment) throws EquipmentAlreadyExistException;
    public Member searchById(int id) throws MemberNotFoundException;
	public List<Gym> searchByName(String equipmentName) throws EquipmentNameNotFoundException;
}
