/**
 * Last Modified On 15/05/2019
 * MemberNotFoundException is thrown whenever member id is searched and member is not found
 *@author mandeshm
 *
 */

package com.cg.fitnessapplicationspring.exception;

public class MemberNotFoundException extends Exception {
	
	
	public MemberNotFoundException() {
		
		
	}
public MemberNotFoundException(String msg) {
		super(msg);
		
	}
	

}
