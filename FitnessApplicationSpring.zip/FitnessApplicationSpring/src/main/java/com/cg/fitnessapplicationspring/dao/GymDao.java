
package com.cg.fitnessapplicationspring.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.fitnessapplicationspring.dto.Equipment;
import com.cg.fitnessapplicationspring.dto.Gym;
import com.cg.fitnessapplicationspring.dto.Member;
import com.cg.fitnessapplicationspring.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationspring.exception.MemberNotFoundException;

 
public interface GymDao {
	
	
	
	
	public Member save(Member member);
	public Member findById(int id);
	public Gym save(Gym gym1);
	public Equipment save(Equipment equipment);
    public List<Gym> findByName(String equipmentName);
	
	
	
	

	
	

}