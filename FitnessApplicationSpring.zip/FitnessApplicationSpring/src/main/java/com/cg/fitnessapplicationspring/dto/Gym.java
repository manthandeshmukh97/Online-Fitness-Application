/**
	 * Last Modified On 11/05/2019
	 *dto layer implementation of Gym class 
	 *@author mandeshm
	 *
	 */

package com.cg.fitnessapplicationspring.dto;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("gymOne")
@Scope(value="prototype")
public class Gym {

	private int id;
	private String address;
    private String exercises;
	private List<Equipment> equipmentName;
	

	public Gym()
	{
		
	}


	public Gym(int id, String address, String exercises, List<Equipment> equipmentName) {
		super();
		this.id = id;
		this.address = address;
		this.exercises = exercises;
		this.equipmentName = equipmentName;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getExercises() {
		return exercises;
	}


	public void setExercises(String exercises) {
		this.exercises = exercises;
	}


	public List<Equipment> getEquipmentName() {
		return equipmentName;
	}


	public void setEquipmentName(List<Equipment> equipmentName) {
		this.equipmentName = equipmentName;
	}


	@Override
	public String toString() {
		return "Gym [id=" + id + ", address=" + address + ", exercises=" + exercises + ", equipmentName="
				+ equipmentName + "]";
	}


	
	


	

}
