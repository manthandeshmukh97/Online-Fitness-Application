import { Component, OnInit } from '@angular/core';
import { GymService } from './app.gymservice';
import { AddGym } from './app.addgym';
import { FormsModule } from '@angular/forms';

@Component({

    selector: 'gym-app',
    templateUrl: 'app.gym.html'

})

export class GymComponent implements OnInit {

    gymOne:AddGym[];
model:any={};
constructor(private proservice:GymService){}

ngOnInit(){

    this.proservice.getAllGym().subscribe((data:AddGym[]) => this.gymOne=data);
}

addGym()
{
//console.log(this.model);
this.proservice.addAllGym(this.model).subscribe((data:any)=>console.log(data));
 }
}