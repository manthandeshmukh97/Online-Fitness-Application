import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {AddGym} from './app.addgym';

@Injectable({

providedIn: 'root'

})



export class GymService{

constructor(private http:HttpClient){}

    getAllGym(){

       return this.http.get("http://localhost:9096/gym/show");
    }

    addAllGym(gymTwo:any){
console.log(gymTwo);
let input = new FormData();
input.append("id", gymTwo.id);
input.append("address", gymTwo.address);
input.append("exercises", gymTwo.exercises);
input.append("equipments.id", gymTwo.equipmentid);
input.append("equipments.name",gymTwo.equipmentname);
input.append("equipments.description",gymTwo.equipmentdescription);



        
        return this.http.post("http://localhost:9096/gym/add",input);
    }
}


