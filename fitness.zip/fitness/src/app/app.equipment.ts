export class Equipment{

    id:number;
    name:string;
    description:string;
}