import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';

@Component({
selector:'search-prod',
templateUrl:'app.searchproduct.html'



})




export class SearchProduct implements OnInit{

    constructor(private activate:ActivatedRoute){}
mydata:any;
    ngOnInit(){

   this.mydata= this.activate.snapshot.params['id'];


    }


    }
    
