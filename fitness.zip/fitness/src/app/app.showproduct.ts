import {Component} from '@angular/core';


@Component({
selector:'show-prod',
templateUrl:'app.showproduct.html'



})




export class ShowProduct{
    
}