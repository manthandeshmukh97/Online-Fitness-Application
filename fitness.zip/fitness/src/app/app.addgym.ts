import {Component} from '@angular/core';
import { Equipment } from "./app.equipment";


@Component({
selector:'add-gym',
templateUrl:'app.addgym.html'



})




export class AddGym{

    id:number;
    address:string;
    exercises:number;
    equipments:Equipment;
    
}