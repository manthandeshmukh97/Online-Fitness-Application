import { Component, OnInit } from '@angular/core';
import { ProductService } from './app.productservice';
import { Product } from './app.product';
@Component({

    selector: 'prod-app',
    templateUrl: 'app.product.html'

})

export class ProductComponent implements OnInit {

    products:Product[];
    pro:any={	"id":165655,
    "name":"Pradip",
    "price":4526.23,
    "description":"dfdfdf",
    "inventory":{
		"id":13784,
		"name":"dfdfdfg"
	}}

constructor(private proservice:ProductService){}

ngOnInit(){

    this.proservice.getAllProduct().subscribe((data:Product[]) => this.products=data);
}

addProduct()
{
    this.proservice.addAllProduct(this.pro).subscribe((data)=>console.log(data));
}
 }