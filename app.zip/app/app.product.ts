import {Component} from '@angular/core';
import { templateJitUrl } from '@angular/compiler'; 
 import {Products} from './app.products';
 import {Images} from './app.images';

@Component({

selector: 'prod-app',
templateUrl: 'app.product.html'

})
export class ProductComponent{
    images:string="assets/pic.jpg";
company:string="Capgemini";

pid:number=101;
pname:string="TV";
pprice:number=1000002.25;

img:string;
image:Images[]=[
{image:"assets/pic1.jpeg"},
{image:"assets/pic2.jpeg"},
{image:"assets/pic.jpg"}
] 

uId:number;
uName:string;
uPrice:number;
num:string;
imageOne:string;
product:Products[]=[

{pid:101, pname:"Mobile",pprice:4526.3},
{pid:102, pname:"TV", pprice:452566.3},
{pid:103, pname:"Laptop", pprice:4534326.3},
];


myData():any{
//alert("Click OK"+this.pid+" "+this.pname+" "+this.pprice);
this.product.push({pid:this.pid, pname:this.pname, pprice:this.pprice});
}

deleteProduct(data:number):any{
  //  alert("Delete"+data);
    this.product.splice(data,1);
}

updateProduct(i):any{
  //  alert("Update"+data);
  this.uId=this.product[i].pid;
  this.uName=this.product[i].pname;
  this.uPrice=this.product[i].pprice;
  this.num=i;
}

update(){
    this.product[this.num].pid=this.uId;
    this.product[this.num].pname=this.uName;
    this.product[this.num].pprice=this.uPrice;

}

selected(data:number):any{
    //alert("product is deleting"+data)
    //this.image.push(data,1);
    
    this.imageOne=this.image[data].image;
    
    
    }
    
    showImage(data:number):any{
    // alert("product is deleting" +data)
    this.img=this.image[data].image;
    
    console.log("asdasdgadg"+this.img);
    }
    
    selectedAdd(data:number):any{
    alert("product is deleting")
    //this.image.push(data,1);
    
    this.imageOne=this.image[data].image;
    
    
    }
}
