


export class Products{

    pid:number;
    pname:string;
    pprice:number;

}