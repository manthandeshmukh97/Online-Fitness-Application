package com.cg.fitnessapplicationjdbc.dbutil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	static Connection conn;
	String driver = null;
	String url = null;
	String uname;
	String upass;
	public static Connection getConnection() {
		Properties prop = new Properties();
		
	try {
		InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
		prop.load(it);
		
		if(prop!=null) {
			String driver = prop.getProperty("jdbc.driver");
			String url = prop.getProperty("jdbc.url");
			String uname = prop.getProperty("jdbc.username");
			String upass = prop.getProperty("jdbc.password");
			Class.forName(driver);
			conn = DriverManager.getConnection(url, uname, upass);
		}
	}
	catch(FileNotFoundException e) 
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e) 
	{
		e.printStackTrace();
	}
	catch(IOException e) {
		e.printStackTrace();
	}
	catch(SQLException e) {
		e.printStackTrace();
	}
	return conn;
}
}
