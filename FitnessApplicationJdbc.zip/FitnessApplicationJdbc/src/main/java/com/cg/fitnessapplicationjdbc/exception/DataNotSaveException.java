package com.cg.fitnessapplicationjdbc.exception;

public class DataNotSaveException extends Exception {
	
	public DataNotSaveException() {
		
	}
	
	public DataNotSaveException(String exceptionMsg) {
		super(exceptionMsg);
	
	}
	
	

}
