package com.cg.fitnessapplicationjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.fitnessapplicationjdbc.dbutil.DBUtil;
import com.cg.fitnessapplicationjdbc.dto.Equipment;
import com.cg.fitnessapplicationjdbc.dto.Gym;
import com.cg.fitnessapplicationjdbc.dto.Member;
import com.cg.fitnessapplicationjdbc.exception.DataNotSaveException;
import com.cg.fitnessapplicationjdbc.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationjdbc.exception.MemberNotFoundException;
import com.cg.fitnessapplicationjdbc.ui.FitnessApplication;
import com.mysql.jdbc.Statement;



public class GymDaoImp implements GymDao {

	private static List<Member> members;
	private static List<Equipment> equips;
	private static List<Gym> gyms;
	Connection conn = null;
	   Statement stmt = null;



//funtion for adding all the data to perform the operations.
	public Member save(Member member) throws DataNotSaveException  {
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		String query=null;
		connection=DBUtil.getConnection();
		try {

			query = "insert into gym(gym_id, gym_address, gym_exercises) values(?, ?, ?)";
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1, member.getGym().getGymId());
			pstmt.setString(2, member.getGym().getGymAddress());
			pstmt.setString(3, member.getGym().getExercises()); 
			pstmt.executeUpdate();

		
			
			String query2 = "insert into equipment(equip_name, equip_description, gym_id) values (?, ?, ?)";
			for(Equipment equip : member.getGym().getEquipName())
			{
				pstmt = connection.prepareStatement(query2);
				pstmt.setString(1, equip.getEquipName());
				pstmt.setString(2, equip.getEquipDescription());
				pstmt.setInt(3, member.getGym().getGymId());
				pstmt.executeUpdate();

			}




			String query3 = "insert into member(mbr_id, mbr_name, mbr_address, mbr_mobile, gym_id) values (?, ?, ?, ?, ?)";
			pstmt=connection.prepareStatement(query3);
			pstmt.setInt(1, member.getId());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getAddress());
			pstmt.setString(4, member.getMobile().toString());
			pstmt.setInt(5, member.getGym().getGymId());
            pstmt.executeUpdate();

			return member;


		}catch (SQLException e) {
			throw new DataNotSaveException("Data Not Save");
		}


	}

//funtion for searching member id in the gym.
	public Member findById(int id) throws MemberNotFoundException {
		try {
			Connection con=DBUtil.getConnection();
			ResultSet rs;
			String resultsql="select m.mbr_id, m.mbr_name, m.mbr_address, m.mbr_mobile, g.gym_id, g.gym_address, g.gym_exercises from gym g inner join member m on m.gym_id = g.gym_id where m.mbr_id=?";
			PreparedStatement pst=con.prepareStatement(resultsql);
			pst.setInt(1,id);
			rs=pst.executeQuery();
			
			Member member = new Member();
			while(rs.next()) {
				
				Gym gym = new Gym();
				member.setId(rs.getInt(1));
				member.setName(rs.getString(2));
				member.setAddress(rs.getString(3));
    			member.setMobile(rs.getBigDecimal(4));
				
				gym.setGymId(rs.getInt(5));
				gym.setGymAddress(rs.getString(6));
				gym.setExercises(rs.getString(7));
			
				member.setGym(gym);
			}
			return member;
			}
			catch(SQLException e) {
				throw new MemberNotFoundException("Member Not Found");
				
			}

	}


	
	//Function for searching equipment name.
	public List<Gym> findByName(String equipName) throws EquipmentNameNotFoundException {
		List<Gym> gymWithEquip=new ArrayList<Gym>();
		Connection con = DBUtil.getConnection();
		String resultsql = null;
		ResultSet result;
		PreparedStatement pstmt = null;
		try {
			
			resultsql = "select e.equip_name, g.gym_id, g.gym_address from equipment e inner join gym g on e.gym_id = g.gym_id where e.equip_name =?";
		    pstmt = con.prepareStatement(resultsql);
		    pstmt.setString(1, equipName);
		    result = pstmt.executeQuery();
		    
			
			while(result.next()) {
				
				String equip_name = result.getString(1);
				int gym_id = result.getInt(2);
				String gym_address = result.getString(3);
				
				Gym gym = new Gym();
				List<Equipment> equips = new ArrayList<Equipment>();
				Equipment equip = new Equipment();
				equip.setEquipName(equip_name);
				equips.add(equip);
				gym.setGymId(gym_id);
				gym.setGymAddress(gym_address);
				gym.setEquipName(equips);
				gymWithEquip.add(gym);
				
			}
			return gymWithEquip;
		}catch(SQLException e)
		{
			
			throw new EquipmentNameNotFoundException("Equipment Name Not Found");
		}
		
		

	

		
	}

}

