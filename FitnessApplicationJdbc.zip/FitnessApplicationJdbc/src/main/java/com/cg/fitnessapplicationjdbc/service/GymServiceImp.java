package com.cg.fitnessapplicationjdbc.service;

import java.util.List;

import com.cg.fitnessapplicationjdbc.dao.GymDao;
import com.cg.fitnessapplicationjdbc.dao.GymDaoImp;
import com.cg.fitnessapplicationjdbc.dto.Gym;
import com.cg.fitnessapplicationjdbc.dto.Member;
import com.cg.fitnessapplicationjdbc.exception.DataNotSaveException;
import com.cg.fitnessapplicationjdbc.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationjdbc.exception.MemberNotFoundException;



public class GymServiceImp implements GymService {

	GymDao gymDao = new GymDaoImp();
	
	public Member addMember(Member member) throws DataNotSaveException {
		// TODO Auto-generated method stub
		return gymDao.save(member);
	}

	
	public Member searchById(int id) throws MemberNotFoundException {
		// TODO Auto-generated method stub
		return gymDao.findById(id);
	}

	
	public List<Gym> searchByName(String equipName) throws EquipmentNameNotFoundException {
		// TODO Auto-generated method stub
		return gymDao.findByName(equipName);
	}

}
