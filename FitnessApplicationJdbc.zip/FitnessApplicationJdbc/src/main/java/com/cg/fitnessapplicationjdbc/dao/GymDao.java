package com.cg.fitnessapplicationjdbc.dao;

import java.util.List;

import com.cg.fitnessapplicationjdbc.dto.Gym;
import com.cg.fitnessapplicationjdbc.dto.Member;
import com.cg.fitnessapplicationjdbc.exception.DataNotSaveException;
import com.cg.fitnessapplicationjdbc.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationjdbc.exception.MemberNotFoundException;



public interface GymDao {
	
	
	public Member save(Member member) throws DataNotSaveException;
	public Member findById(int id) throws MemberNotFoundException;
	public List<Gym> findByName(String equipName) throws EquipmentNameNotFoundException;
	
	
	
	

	
	

}
