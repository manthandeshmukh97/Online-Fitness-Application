package com.cg.fitnessapplicationjdbc.exception;

public class MemberNotFoundException extends Exception {
	
	
	public MemberNotFoundException() {
		
		
	}
public MemberNotFoundException(String msg) {
		super(msg);
		
	}
	

}
