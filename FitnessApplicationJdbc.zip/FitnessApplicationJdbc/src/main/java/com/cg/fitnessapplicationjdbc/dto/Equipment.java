package com.cg.fitnessapplicationjdbc.dto;

public class Equipment {

	private String equipName;
	private String equipDescription;
	
	public Equipment()
	{
		
	}

	

	



	






	public Equipment(String equipName, String equipDescription) {
		super();
		this.equipName = equipName;
		this.equipDescription = equipDescription;
	}














	






	public String getEquipName() {
		return equipName;
	}


	public void setEquipName(String equipName) {
		this.equipName = equipName;
	}

	public String getEquipDescription() {
		return equipDescription;
	}

	public void setEquipDescription(String equipDescription) {
		this.equipDescription = equipDescription;
	}














	@Override
	public String toString() {
		return "Equipment [equipName=" + equipName + ", equipDescription=" + equipDescription + "]";
	}









	
	
	
	
	
	

}
