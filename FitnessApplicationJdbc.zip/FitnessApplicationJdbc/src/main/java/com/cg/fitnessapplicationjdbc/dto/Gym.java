package com.cg.fitnessapplicationjdbc.dto;

import java.util.List;



public class Gym {

	private String exercises;
	private String gymAddress;
	private List<Equipment> equipName;
	private int gymId;

	

	public Gym()
	{
	
	}


	


	public Gym(String exercises, String gymAddress, List<Equipment> equipName, int gymId) {
		super();
		this.exercises = exercises;
		this.gymAddress = gymAddress;
		this.equipName = equipName;
		this.gymId = gymId;
		
	}

    public String getExercises() {
		return exercises;
	}


	public void setExercises(String exercises) {
		this.exercises = exercises;
	}


	public String getGymAddress() {
		return gymAddress;
	}


	public void setGymAddress(String gymAddress) {
		this.gymAddress = gymAddress;
	}


	public List<Equipment> getEquipName() {
		return equipName;
	}


	public void setEquipName(List<Equipment> equipName) {
		this.equipName = equipName;
	}

	public int getGymId() {
		return gymId;
	}


	public void setGymId(int gymId) {
		this.gymId = gymId;
	}





	@Override
	public String toString() {
		return "Gym [exercises=" + exercises + ", gymAddress=" + gymAddress + ", equipName=" + equipName + ", gymId="
				+ gymId + "]";
	}





	


	


	

	

	




}

