package com.cg.fitnessapplicationjdbc.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.fitnessapplicationjdbc.dto.Equipment;
import com.cg.fitnessapplicationjdbc.dto.Gym;
import com.cg.fitnessapplicationjdbc.dto.Member;
import com.cg.fitnessapplicationjdbc.exception.DataNotSaveException;
import com.cg.fitnessapplicationjdbc.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationjdbc.exception.MemberNotFoundException;
import com.cg.fitnessapplicationjdbc.service.GymService;
import com.cg.fitnessapplicationjdbc.service.GymServiceImp;



public class FitnessApplication {


	public static List<Member> members;
	public static List<Equipment> equips;
	public static List<Gym> gyms;         

	public static void main(String[] args) {

		GymService gymservice = new GymServiceImp();

		Scanner scan = new Scanner(System.in);
		int choice = 0;

		do {
			printMenu();
			System.out.println("Enter Choice:-");
			choice = scan.nextInt();

			switch(choice) {
			
			//adding data from the user

			case 1:

				System.out.println("Enter Gym Id:-");
				int gymId = scan.nextInt();
				System.out.println("Enter Gym Address:-");
				String gymAddress = scan.next();
				System.out.println("Enter Gym Exercises:-");
				String exercise = scan.next();

				System.out.println("Enter Member Id:-");
				int id = scan.nextInt();
				System.out.println("Enter Member Name:-");
				String name = scan.next();
				System.out.println("Enter Member Address:-");
				String address = scan.next();
				System.out.println("Enter Member Mobile No:-");
				BigDecimal mobile = scan.nextBigDecimal();

				System.out.println("Enter Equipment Name:-");
				String ename = scan.next();
				System.out.println("Enter Equipment Description:-");
				String edesc = scan.next();

				List<Equipment> equ = new ArrayList<Equipment>();
				Equipment equip = new Equipment(ename, edesc);
				equ.add(equip);
				Member member1=new Member();
				Gym gym1=new Gym();
				member1.setId(id);
				member1.setName(name);
				member1.setAddress(address);
				member1.setMobile(mobile);

				gym1.setGymId(gymId);
				gym1.setGymAddress(gymAddress);
				gym1.setExercises(exercise);
				gym1.setEquipName(equ);
				member1.setGym(gym1);

				try {
					gymservice.addMember(member1);

					System.out.println("Member Added...Your Id Is:-"+member1.getId());
				} catch (DataNotSaveException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
				
				//case statement for searching member id that user have enter earlier


			case 2:

				System.out.println("Enter Member Id:-");
				int memberId = scan.nextInt();
				Member member;
				try {
					member = gymservice.searchById(memberId);
					System.out.println("Please find details of member id "+memberId+
							"\nName : "+member.getName()+
							"\nAddress : "+member.getAddress()+
							"\nMobile Number : "+member.getMobile()+
							(null==member.getGym()?"\n\nGym Details are not available.":"\nGym Details\nGym Id : "+member.getGym().getGymId()+
							"\nGym Address : "+member.getGym().getGymAddress()+"\nExercises in the Gym : "+member.getGym().getExercises()));
				} 
				catch (MemberNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
				
				//case statement for searching equipment name in the gym


			case 3:

				System.out.println("Please enter equipment name to be search:-");
				String equipName = scan.next();
				List<Gym> gymList;
				try {
					gymList = gymservice.searchByName(equipName);

					for(Gym gym:gymList)
					{
						System.out.println("\nGym Id : "+gym.getGymId()+"\nGym Address : "+gym.getGymAddress());
					}
				} catch (EquipmentNameNotFoundException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			}
		}while(choice != 3);
	}

	private static void printMenu() {
		// TODO Auto-generated method stub
		System.out.println("*******************");
		System.out.println("Fitness Application");
		System.out.println("*******************\n");

		System.out.println("1. Add Member");
		System.out.println("2. Search Member By Id");
		System.out.println("3. Search Equipment By Name");




	}
}





