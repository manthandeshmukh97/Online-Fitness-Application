package com.cg.fitnessapplicationjdbc.service;

import java.util.List;

import com.cg.fitnessapplicationjdbc.dto.Gym;
import com.cg.fitnessapplicationjdbc.dto.Member;
import com.cg.fitnessapplicationjdbc.exception.DataNotSaveException;
import com.cg.fitnessapplicationjdbc.exception.EquipmentNameNotFoundException;
import com.cg.fitnessapplicationjdbc.exception.MemberNotFoundException;



public interface GymService {
	public Member addMember(Member member) throws DataNotSaveException;
	public Member searchById(int id) throws MemberNotFoundException;
	public List<Gym> searchByName(String equipName) throws EquipmentNameNotFoundException;
}
